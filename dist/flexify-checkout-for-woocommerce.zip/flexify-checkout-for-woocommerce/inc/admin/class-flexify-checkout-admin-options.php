<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

class Flexify_Checkout_Admin_Options extends Flexify_Checkout_Autoloader {

  /**
   * Flexify_Checkout_Admin constructor.
   *
   * @since 1.0.0
   * @access public
   */
  public function __construct() {
    parent::__construct();

    add_action( 'admin_menu', array( $this, 'flexify_checkout_admin_menu' ) );
    add_action( 'admin_enqueue_scripts', array( $this, 'flexify_checkout_admin_scripts' ) );
    add_action( 'wp_ajax_flexify_checkout_ajax_save_options', array( $this, 'flexify_checkout_ajax_save_options_callback' ) );
    add_action( 'wp_ajax_nopriv_flexify_checkout_ajax_save_options', array( $this, 'flexify_checkout_ajax_save_options_callback' ) );
  }

  /**
   * Function for create submenu in WooCommerce
   * 
   * @since 1.0.0
   * @access public
   * @return array
   */
  public function flexify_checkout_admin_menu() {
    add_submenu_page(
      'woocommerce', // parent page slug
      esc_html__( 'Flexify Checkout para WooCommerce', 'flexify-checkout-for-woocommerce'), // page title
      esc_html__( 'Flexify Checkout', 'flexify-checkout-for-woocommerce'), // submenu title
      'manage_woocommerce', // user capabilities
      'flexify-checkout-for-woocommerce', // page slug
      array( $this, 'flexify_checkout_settings_page' ), // public function for print content page
    );
  }


  /**
   * Plugin general setting page and save options
   * 
   * @since 1.0.0
   * @access public
   */
  public function flexify_checkout_settings_page() {
    include_once FLEXIFY_CHECKOUT_PATH . 'inc/admin/settings.php';
  }


  /**
   * Enqueue admin scripts in page settings only
   * 
   * @since 1.0.0
   * @access public
   * @return void
   */
  public function flexify_checkout_admin_scripts() {
    $url = $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];

    if ( false !== strpos( $url, 'admin.php?page=flexify-checkout' ) ) {
        wp_enqueue_media();
        wp_enqueue_script( 'flexify-checkout-admin-scripts', FLEXIFY_CHECKOUT_URL . 'assets/admin/js/flexify-checkout-admin-scripts.js', array('jquery', 'media-upload'), FLEXIFY_CHECKOUT_VERSION );
        wp_enqueue_style( 'flexify-checkout-admin-styles', FLEXIFY_CHECKOUT_URL . 'assets/admin/css/flexify-checkout-admin-styles.css', array(), FLEXIFY_CHECKOUT_VERSION );
    
        wp_localize_script( 'flexify-checkout-admin-scripts', 'flexify_checkout_params', array(
          'ajax_url' => admin_url( 'admin-ajax.php' ),
        ) );
    }
  }


  /**
   * Save options in AJAX
   * 
   * @since 1.0.0
   * @return void
   * @package MeuMouse.com
   */
  public function flexify_checkout_ajax_save_options_callback() {
    if ( isset( $_POST['form_data'] ) ) {
        // Convert serialized data into an array
        parse_str( $_POST['form_data'], $form_data );

        $options = get_option( 'flexify_checkout_settings' );
        $options['enable_flexify_checkout'] = isset( $form_data['enable_flexify_checkout'] ) ? 'yes' : 'no';
        $options['enable_company_field'] = isset( $form_data['enable_company_field'] ) ? 'yes' : 'no';
        $options['enable_street_number_field'] = isset( $form_data['enable_street_number_field'] ) ? 'yes' : 'no';
        $options['enable_back_to_shop_button'] = isset( $form_data['enable_back_to_shop_button'] ) ? 'yes' : 'no';
        $options['enable_skip_cart_page'] = isset( $form_data['enable_skip_cart_page'] ) ? 'yes' : 'no';
        $options['enable_terms_is_checked_default'] = isset( $form_data['enable_terms_is_checked_default'] ) ? 'yes' : 'no';
        $options['enable_aditional_notes'] = isset( $form_data['enable_aditional_notes'] ) ? 'yes' : 'no';
        $options['enable_optimize_for_digital_products'] = isset( $form_data['enable_optimize_for_digital_products'] ) ? 'yes' : 'no';
        $options['enable_link_image_products'] = isset( $form_data['enable_link_image_products'] ) ? 'yes' : 'no';
        $options['enable_fill_address'] = isset( $form_data['enable_fill_address'] ) ? 'yes' : 'no';
        $options['enable_add_remove_products'] = isset( $form_data['enable_add_remove_products'] ) ? 'yes' : 'no';
        $options['enable_ddi_phone_field'] = isset( $form_data['enable_ddi_phone_field'] ) ? 'yes' : 'no';
        $options['enable_hide_coupon_code_field'] = isset( $form_data['enable_hide_coupon_code_field'] ) ? 'yes' : 'no';
        $options['enable_auto_apply_coupon_code'] = isset( $form_data['enable_auto_apply_coupon_code'] ) ? 'yes' : 'no';
        $options['enable_assign_guest_orders'] = isset( $form_data['enable_assign_guest_orders'] ) ? 'yes' : 'no';
        $options['enable_inter_bank_pix_api'] = isset( $form_data['enable_inter_bank_pix_api'] ) ? 'yes' : 'no';
        $options['enable_inter_bank_ticket_api'] = isset( $form_data['enable_inter_bank_ticket_api'] ) ? 'yes' : 'no';
        $options['flexify_checkout_theme'] = isset( $form_data['flexify_checkout_theme'] ) ? 'modern' : 'modern';

        // Merge the form data with the default options
        $updated_options = wp_parse_args( $form_data, $options );

        // Save the updated options
        update_option( 'flexify_checkout_settings', $updated_options );

        $response = array(
          'status' => 'success',
          'options' => $updated_options,
        );

        echo wp_json_encode( $response ); // Send JSON response
    }

    wp_die();
  }

}

new Flexify_Checkout_Admin_Options();