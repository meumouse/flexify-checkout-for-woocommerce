<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; ?>

<div id="fields" class="nav-content">
    <table class="form-table">
        <tr>
            <th>
                <?php echo esc_html__( 'Ativar campo de Empresa', 'flexify-checkout-for-woocommerce' ) ?>
                <span class="flexify-checkout-description"><?php echo esc_html__( 'Ative esta opção para exibir o campo "Empresa" na finalização de compras.', 'flexify-checkout-for-woocommerce' ) ?></span>
            </th>
            <td>
                <div class="form-check form-switch">
                <input type="checkbox" class="toggle-switch" id="enable_company_field" name="enable_company_field" value="yes" <?php checked( self::get_setting('enable_company_field') === 'yes' ); ?> />
                </div>
            </td>
        </tr>
        <tr>
            <th>
                <?php echo esc_html__( 'Ativar campo de complemento', 'flexify-checkout-for-woocommerce' ) ?>
                <span class="flexify-checkout-description"><?php echo esc_html__( 'Ative esta opção para mostrar o campo de complemento na etapa de entrega.', 'flexify-checkout-for-woocommerce' ) ?></span>
            </th>
            <td>
                <div class="form-check form-switch">
                <input type="checkbox" class="toggle-switch" id="enable_address_field_2" name="enable_address_field_2" value="yes" <?php checked( self::get_setting('enable_address_field_2') === 'yes' ); ?> />
                </div>
            </td>
        </tr>
        <tr>
            <th>
                <?php echo esc_html__( 'Mostrar campo de observações adicionais', 'flexify-checkout-for-woocommerce' ) ?>
                <span class="flexify-checkout-description"><?php echo esc_html__( 'Ative esta opção para mostrar o campo de observações adicionais no pedido.', 'flexify-checkout-for-woocommerce' ) ?></span>
            </th>
            <td>
                <div class="form-check form-switch">
                <input type="checkbox" class="toggle-switch" id="enable_aditional_notes" name="enable_aditional_notes" value="yes" <?php checked( self::get_setting('enable_aditional_notes') === 'yes' ); ?> />
                </div>
            </td>
        </tr>
        <tr>
            <th>
                <?php echo esc_html__( 'Ocultar campo de cupom de desconto', 'flexify-checkout-for-woocommerce' ) ?>
                <span class="flexify-checkout-description"><?php echo esc_html__( 'Quando ativado, o campo do cupom não será exibido aos usuários e eles não poderão inserir um código de cupom. No entanto, você pode aplicar um cupom automaticamente.', 'flexify-checkout-for-woocommerce' ) ?></span>
            </th>
            <td>
                <div class="form-check form-switch">
                <input type="checkbox" class="toggle-switch" id="enable_hide_coupon_code_field" name="enable_hide_coupon_code_field" value="yes" <?php checked( self::get_setting('enable_hide_coupon_code_field') === 'yes' ); ?> />
                </div>
            </td>
        </tr>
    </table>
</div>