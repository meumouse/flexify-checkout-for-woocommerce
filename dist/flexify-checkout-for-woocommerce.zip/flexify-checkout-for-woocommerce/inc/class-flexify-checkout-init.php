<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Class for init plugin
 * 
 * @since 1.0.0
 * @version 2.3.0
 * @package MeuMouse.com
 */
class Flexify_Checkout_Init {

  public $responseObj;
  public $licenseMessage;
  public $showMessage = false;
  public $activateLicense = false;
  public $deactivateLicense = false;
  
  /**
   * Construct function
   * 
   * @since 1.0.0
   * @return void
   */
  public function __construct() {
    // set default options
    add_action( 'plugins_loaded', array( $this, 'flexify_checkout_set_default_options' ), 998 );

    // load api
    add_action( 'plugins_loaded', array( $this, 'flexify_checkout_connect_api' ), 999 );
  }


  /**
   * Set default options
   * 
   * @since 1.0.0
   * @return array
   */
  public function set_default_data_options() {
    $options = array(
      'enable_flexify_checkout' => 'yes',
      'enable_company_field' => 'no',
      'enable_autofill_company_info' => 'no',
      'enable_street_number_field' => 'yes',
      'enable_back_to_shop_button' => 'no',
      'enable_skip_cart_page' => 'no',
      'enable_terms_is_checked_default' => 'yes',
      'enable_aditional_notes' => 'no',
      'enable_optimize_for_digital_products' => 'no',
      'enable_link_image_products' => 'no',
      'enable_fill_address' => 'yes',
      'enable_add_remove_products' => 'yes',
      'enable_ddi_phone_field' => 'no',
      'enable_hide_coupon_code_field' => 'no',
      'enable_auto_apply_coupon_code' => 'no',
      'enable_assign_guest_orders' => 'yes',
      'enable_inter_bank_pix_api' => 'no',
      'enable_inter_bank_ticket_api' => 'no',
      'checkout_header_type' => 'logo',
      'search_image_header_checkout' => '',
      'header_width_image_checkout' => '200',
      'unit_header_width_image_checkout' => 'px',
      'text_brand_checkout_header' => 'Checkout',
      'set_primary_color' => '#141D26',
      'set_primary_color_on_hover' => '#33404D',
      'set_placeholder_color' => '#33404D',
      'flexify_checkout_theme' => 'modern',
      'input_border_radius' => '0.5',
      'unit_input_border_radius' => 'rem',
      'enable_address_field_2' => 'no',
      'set_font_family' => 'Inter',
      'h2_size' => '1.5',
      'h2_size_unit' => 'rem',
      'enable_thankyou_page_template' => 'yes',
      'pix_gateway_title' => 'Pix',
      'pix_gateway_description' => 'Pague via transferência imediata Pix a qualquer hora, a aprovação é imediata!',
      'pix_gateway_email_instructions' => 'Clique no botão abaixo para ver os dados de pagamento do seu Pix.',
      'pix_gateway_receipt_key' => '',
      'pix_gateway_expires' => '30',
      'bank_slip_gateway_title' => 'Boleto bancário',
      'bank_slip_gateway_description' => 'Pague com boleto. Aprovação de 1 a 3 dias úteis após o pagamento.',
      'bank_slip_gateway_email_instructions' => 'Clique no botão abaixo para acessar seu boleto ou utilize a linha digitável para pagar via Internet Banking.',
      'bank_slip_gateway_expires' => '3',
      'bank_slip_gateway_footer_message' => 'Pagamento do pedido #{order_id}. Não receber após o vencimento.',
      'inter_bank_client_id' => '',
      'inter_bank_client_secret' => '',
      'inter_bank_debug_mode' => 'no',
    );

    return $options;
  }


  /**
   * Gets the items from the array and inserts them into the option if it is empty,
   * or adds new items with default value to the option
   * 
   * @since 2.3.0
   * @return void
   */
  public function flexify_checkout_set_default_options() {
      $get_options = $this->set_default_data_options();
      $default_options = get_option('flexify_checkout_settings', array());

      if ( empty( $default_options ) ) {
          $options = $get_options;
          update_option('flexify_checkout_settings', $options);
      } else {
          $options = $default_options;
  
          foreach ( $get_options as $key => $value ) {
              if ( !isset( $options[$key] ) ) {
                  $options[$key] = $value;
              }
          }
  
          update_option('flexify_checkout_settings', $options);
      }
  }    


  /**
   * Checks if the option exists and returns the indicated array item
   * 
   * @since 1.0.0
   * @version 2.3.0
   * @param $key | Array key
   * @return mixed | string or false
   */
  public static function get_setting( $key ) {
    $default_options = get_option('flexify_checkout_settings', array());

    // check if array key exists and return key
    if ( isset( $default_options[$key] ) ) {
        return $default_options[$key];
    }

    return false;
  }


  /**
   * Load API settings
   * 
   * @since 1.0.0
   * @version 2.5.0
   */
  public function flexify_checkout_connect_api() {
    if ( current_user_can('manage_woocommerce') ) {
      $this->responseObj = new stdClass();
      $this->responseObj->is_valid = false;
      $message = "";
      $license_key = get_option( 'flexify_checkout_license_key', '' );
  
      // Save settings on active license
      if (  isset( $_POST['flexify_checkout_active_license'] ) ) {
          update_option( 'flexify_checkout_license_key', $_POST );
          $license_key = !empty( $_POST['flexify_checkout_license_key'] ) ? $_POST['flexify_checkout_license_key'] : '';
          update_option( 'flexify_checkout_license_key', $license_key ) || add_option('flexify_checkout_license_key', $license_key );
          update_option( '_site_transient_update_plugins', '' );
      }

      if ( get_option( 'flexify_checkout_license_status' ) !== 'valid' ) {
        update_option( 'flexify_checkout_license_key', '' );
        update_option( 'flexify_checkout_license_status', 'invalid' );
      }

      // Check on the server if the license is valid and update responses and options
      if ( Flexify_Checkout_Api::CheckWPPlugin( $license_key, $this->licenseMessage, $this->responseObj, __FILE__ ) ) {
          if ( $this->responseObj && $this->responseObj->is_valid ) {
            update_option( 'flexify_checkout_license_status', 'valid' );
          } else {
            update_option( 'flexify_checkout_license_status', 'invalid' );
            wp_cache_delete( 'flexify_checkout_url_server_cache' );
          }

          if ( isset( $_POST['flexify_checkout_active_license'] ) && self::license_valid() ) {
            $this->activateLicense = true;
          }
      } else {
          if ( !empty( $license_key ) && !empty( $this->licenseMessage ) ) {
              $this->showMessage = true;
          }
      }

      // Save settings on deactive license, or remove license status if it is invalid
      if ( isset( $_POST['flexify_checkout_deactive_license'] ) ) {
        if ( Flexify_Checkout_Api::RemoveLicenseKey( FLEXIFY_CHECKOUT_FILE, $message ) ) {
          update_option( 'flexify_checkout_license_status', 'invalid' );
          delete_option( 'flexify_checkout_license_key' );
          update_option( '_site_transient_update_plugins', '' );
          wp_cache_delete( 'flexify_checkout_url_server_cache' );
          delete_transient('flexify_checkout_api_request_cache');
          delete_transient('flexify_checkout_api_response_cache');
          delete_option('flexify_checkout_license_response_object');

          $this->deactivateLicense = true;
        }
      }

      // clear activation cache
      if ( isset( $_POST['flexify_checkout_clear_activation_cache'] ) || get_option( 'flexify_checkout_license_status' ) !== 'valid' ) {
        delete_transient('flexify_checkout_api_request_cache');
        delete_transient('flexify_checkout_api_response_cache');
        delete_option('flexify_checkout_license_response_object');
      }
    }
  }


  /**
   * Check if license if valid
   * 
   * @since 2.5.0
   * @return bool
   */
  public static function license_valid() {
    $object_query = get_option('flexify_checkout_license_response_object');

    if ( ! empty( $object_query ) && $object_query->is_valid ) {
      return true;
    } else {
      return false;
    }
  }

}

new Flexify_Checkout_Init();