<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
  exit;
}

?>

<div id="design-settings" class="nav-content ">
   <table class="form-table" >
      <tr>
        <th>
           <?php echo esc_html__( 'Centralizar melhor parcela e desconto na grade de produtos', 'flexify-checkout-for-woocommerce' ) ?>
           <span class="flexify-checkout-description"><?php echo esc_html__('Se ativo, irá centralizar a melhor parcela e desconto na grade de produtos.', 'flexify-checkout-for-woocommerce' ) ?></span>
        </th>
        <td>
           <div class="form-check form-switch">
              <input type="checkbox" class="toggle-switch" id="center_group_elements_loop" name="center_group_elements_loop" value="yes" <?php checked( isset( $options['center_group_elements_loop'] ) == 'yes' ); ?> />
           </div>
        </td>
      </tr>
      <tr>
         <td class="container-separator"></td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Cor do preço com desconto', 'flexify-checkout-for-woocommerce' ) ?>
            <span class="flexify-checkout-description"><?php echo esc_html__( 'A cor de fundo será gerada automaticamente com 10% de transparência a partir da cor informada. Esta configuração também altera a cor do emblema de aprovação imediata e desconto no checkout.' ) ?></span>
         </th>
         <td>
            <input type="color" name="discount_main_price_color" class="form-control-color" value="<?php echo $this->getSetting( 'discount_main_price_color' ) ?>"/>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Tamanho da fonte do preço com desconto', 'flexify-checkout-for-woocommerce' ) ?>
         </th>
         <td>
            <div class="input-group">
               <input type="text" name="font_size_discount_price" class="form-control input-control-wd-5 design-parameters" value="<?php echo $this->getSetting( 'font_size_discount_price' ) ?>"/>
               <select id="unit_font_size_discount_price" class="form-select" name="unit_font_size_discount_price">
                  <option value="px" <?php echo ( $this->getSetting( 'unit_font_size_discount_price' ) == 'px' ) ? "selected=selected" : ""; ?>><?php echo esc_html__( 'px', 'flexify-checkout-for-woocommerce' ) ?></option>
                  <option value="em" <?php echo ( $this->getSetting( 'unit_font_size_discount_price' ) == 'em' ) ? "selected=selected" : ""; ?>><?php echo esc_html__( 'em', 'flexify-checkout-for-woocommerce' ) ?></option>
                  <option value="rem" <?php echo ( $this->getSetting( 'unit_font_size_discount_price' ) == 'rem' ) ? "selected=selected" : ""; ?>><?php echo esc_html__( 'rem', 'flexify-checkout-for-woocommerce' ) ?></option>
               </select>
            </div>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Margem superior do preço com desconto', 'flexify-checkout-for-woocommerce' ) ?>
         </th>
         <td>
            <div class="input-group">
               <input type="text" name="margin_top_discount_price" class="form-control input-control-wd-5 design-parameters" value="<?php echo $this->getSetting( 'margin_top_discount_price' ) ?>"/>
               <select id="unit_margin_top_discount_price" class="form-select" name="unit_margin_top_discount_price">
                  <option value="px" <?php echo ( $this->getSetting( 'unit_margin_top_discount_price' ) == 'px' ) ? "selected=selected" : ""; ?>><?php echo esc_html__( 'px', 'flexify-checkout-for-woocommerce' ) ?></option>
                  <option value="em" <?php echo ( $this->getSetting( 'unit_margin_top_discount_price' ) == 'em' ) ? "selected=selected" : ""; ?>><?php echo esc_html__( 'em', 'flexify-checkout-for-woocommerce' ) ?></option>
                  <option value="rem" <?php echo ( $this->getSetting( 'unit_margin_top_discount_price' ) == 'rem' ) ? "selected=selected" : ""; ?>><?php echo esc_html__( 'rem', 'flexify-checkout-for-woocommerce' ) ?></option>
               </select>
            </div>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Margem inferior do preço com desconto', 'flexify-checkout-for-woocommerce' ) ?>
         </th>
         <td>
            <div class="input-group">
               <input type="text" name="margin_bottom_discount_price" class="form-control input-control-wd-5 design-parameters" value="<?php echo $this->getSetting( 'margin_bottom_discount_price' ) ?>"/>
               <select id="unit_margin_bottom_discount_price" class="form-select" name="unit_margin_bottom_discount_price">
                  <option value="px" <?php echo ( $this->getSetting( 'unit_margin_bottom_discount_price' ) == 'px' ) ? "selected=selected" : ""; ?>><?php echo esc_html__( 'px', 'flexify-checkout-for-woocommerce' ) ?></option>
                  <option value="em" <?php echo ( $this->getSetting( 'unit_margin_bottom_discount_price' ) == 'em' ) ? "selected=selected" : ""; ?>><?php echo esc_html__( 'em', 'flexify-checkout-for-woocommerce' ) ?></option>
                  <option value="rem" <?php echo ( $this->getSetting( 'unit_margin_bottom_discount_price' ) == 'rem' ) ? "selected=selected" : ""; ?>><?php echo esc_html__( 'rem', 'flexify-checkout-for-woocommerce' ) ?></option>
               </select>
            </div>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Arredondamento do preço com desconto', 'flexify-checkout-for-woocommerce' ) ?>
            <span class="flexify-checkout-description"><?php echo esc_html__( 'Raio da borda do emblema do preço com desconto.' ) ?></span>
         </th>
         <td>
            <div class="input-group">
               <input type="text" name="border_radius_discount_main_price" class="form-control input-control-wd-5 allow-number-and-dots" value="<?php echo $this->getSetting( 'border_radius_discount_main_price' ) ?>"/>
               <select id="unit_border_radius_discount_main_price" class="form-select" name="unit_border_radius_discount_main_price">
                  <option value="px" <?php echo ( $this->getSetting( 'unit_border_radius_discount_main_price' ) == 'px' ) ? "selected=selected" : ""; ?>><?php echo esc_html__( 'px', 'flexify-checkout-for-woocommerce' ) ?></option>
                  <option value="em" <?php echo ( $this->getSetting( 'unit_border_radius_discount_main_price' ) == 'em' ) ? "selected=selected" : ""; ?>><?php echo esc_html__( 'em', 'flexify-checkout-for-woocommerce' ) ?></option>
                  <option value="rem" <?php echo ( $this->getSetting( 'unit_border_radius_discount_main_price' ) == 'rem' ) ? "selected=selected" : ""; ?>><?php echo esc_html__( 'rem', 'flexify-checkout-for-woocommerce' ) ?></option>
               </select>
            </div>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Ícone do preço com desconto', 'flexify-checkout-for-woocommerce' ) ?>
            <span class="flexify-checkout-description"><?php echo esc_html__( 'Informe uma classe de ícone do Font Awesome. Ou deixe em branco para não exibir.' ) ?></span><a class="fancy-link mt-2" href="https://fontawesome.com/search?o=r&m=free" target="_blank"><?php echo esc_html__( 'Acessar Font Awesome', 'flexify-checkout-for-woocommerce' ) ?></a>
         </th>
         <td>
            <input type="text" name="icon_main_price" class="form-control input-control-wd-10" placeholder="fa-brands fa-pix" value="<?php echo $this->getSetting( 'icon_main_price' ) ?>"/>
         </td>
      </tr>
   </table>
</div>