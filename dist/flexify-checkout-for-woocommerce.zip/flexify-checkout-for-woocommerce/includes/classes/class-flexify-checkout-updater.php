<?php

namespace FlexifyCheckout\Updater;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class to make requests to a remote server to get plugin versions and updates
 * 
 * @since 1.0.0
 * @package MeuMouse.com
 */
if ( !class_exists('Flexify_Checkout_Updater') ) {
    class Flexify_Checkout_Updater {

        public $plugin_slug;
        public $info_cache_key;
        public $update_cache_key;
        public $cache_allowed;
        private static $instance;

        public static function get_instance() {
            if (null === self::$instance) {
                self::$instance = new self();
            }
            return self::$instance;
        }

        public function __construct() {
            if ( defined( 'FLEXIFY_CHECKOUT_DEV_MODE' ) ) {
                add_filter( 'https_ssl_verify', '__return_false' );
                add_filter( 'https_local_ssl_verify', '__return_false' );
                add_filter( 'http_request_host_is_external', '__return_true' );
            }

            $this->plugin_slug = Flexify_Checkout()->token;
            $this->info_cache_key = 'flexify_checkout_plugin_info';
            $this->update_cache_key = 'flexify_checkout_check_updates';
            $this->cache_allowed = false;

            add_filter( 'plugins_api', array( $this, 'info' ), 20, 3 );
            add_filter( 'plugin_row_meta', array( $this, 'add_check_for_updates_link' ), 10, 2 );
            add_action( 'wp_ajax_check_for_plugin_updates', array( $this, 'check_for_plugin_updates' ) );
            add_filter( 'site_transient_update_plugins', array( $this, 'update' ) );
            add_action( 'upgrader_process_complete', array( $this, 'purge' ), 10, 2 );
        }


        /**
         * Request on remote server
         * 
         * @since 1.0.0
         * @return array
         * @package MeuMouse.com
         */
        public function request() {
            // Tente obter os dados em cache
            $cached_data = wp_cache_get('flexify_checkout_check_updates');
        
            if ( false === $cached_data ) {
                // Os dados não estão em cache, faça a solicitação para obter os dados
                $remote = wp_remote_get('https://raw.githubusercontent.com/meumouse/flexify-checkout/main/updater/flexify-checkout-updater.json', [
                    'timeout' => 10,
                    'headers' => [
                        'Accept' => 'application/json'
                    ]
                ]);
        
                if ( ! is_wp_error($remote) && 200 === wp_remote_retrieve_response_code($remote) ) {
                    // Decodifique os dados JSON da resposta
                    $remote_data = json_decode(wp_remote_retrieve_body($remote));
        
                    // Armazene em cache os dados obtidos
                    wp_cache_set('flexify_checkout_check_updates', $remote_data, '', DAY_IN_SECONDS);
                } else {
                    // Se a solicitação falhar, retorne false
                    return false;
                }
            } else {
                // Os dados estão em cache, use os dados em cache
                $remote_data = $cached_data;
            }
        
            return $remote_data;
        }


        /**
         * Get plugin info
         * 
         * @since 1.0.0
         * @return array
         * @package MeuMouse.com
         */
        public function info( $response, $action, $args ) {
            if ( 'plugin_information' !== $action ) {
                return $response;
            }
        
            if ( empty( $args->slug ) || $this->plugin_slug !== $args->slug ) {
                return $response;
            }
        
            list( $plugin_info, $updates ) = $this->request();
        
            if ( ! $plugin_info ) {
                return $response;
            }
        
            $response = new \stdClass();
        
            $response->name = $plugin_info->name;
            $response->slug = $plugin_info->slug;
            $response->version = $plugin_info->version;
            $response->tested = $plugin_info->tested;
            $response->requires = $plugin_info->requires;
            $response->author = $plugin_info->author;
            $response->author_profile = $plugin_info->author_profile;
            $response->homepage = $plugin_info->homepage;
            $response->download_link = $plugin_info->download_url;
            $response->trunk = $plugin_info->download_url;
            $response->requires_php = $plugin_info->requires_php;
            $response->last_updated = $plugin_info->last_updated;
        
            $response->sections = [
                'description' => $plugin_info->sections->description,
                'installation' => $plugin_info->sections->installation,
                'changelog' => $plugin_info->sections->changelog
            ];
        
            if ( ! empty( $plugin_info->banners ) ) {
                $response->banners = [
                    'low' => $plugin_info->banners->low,
                    'high' => $plugin_info->banners->high
                ];
            }
        
            return $response;
        }


        /**
         * Add "Check for Updates" link to plugin row meta
         *
         * @param array  $links Plugin action links.
         * @param string $file  Plugin file.
         * @return array
         */
        public function add_check_for_updates_link( $links, $file ) {
            if ( $file === $this->plugin_slug . '/' . $this->plugin_slug . '.php' ) {
                $update_link = '<a href="' . wp_nonce_url( admin_url( 'admin-ajax.php?action=check_for_plugin_updates&slug=' . $this->plugin_slug ), 'check_updates') . '">' . __( 'Verificar atualizações', 'flexify-checkout' ) . '</a>';
                array_push( $links, $update_link );
            }

            return $links;
        }


        /**
         * Callback for handle the update check
         * 
         * @since 1.0.0
         * @return void
         */
        public function check_for_plugin_updates() {
            // Verify the nonce for security
            if ( !isset( $_REQUEST['_wpnonce'] ) || !wp_verify_nonce( $_REQUEST['_wpnonce'], 'check_updates') ) {
                wp_die( __( 'Solicitação não autorizada.', 'flexify-checkout' ) );
            }
        
            // Check for updates logic here
            // ...
        
            // Redirect back to the plugins page after checking for updates
            wp_safe_redirect( admin_url( 'plugins.php' ) );
            exit();
        }


        /**
         * Update plugin
         * 
         * @since 1.0.0
         * @return string
         * @package MeuMouse.com
         */
        public function update( $transient ) {
            if ( empty( $transient->checked ) ) {
                return $transient;
            }
        
            $cached_data = $this->request();
        
            if ( $cached_data && version_compare( Flexify_Checkout()->version, $cached_data->version, '<' ) && version_compare( $cached_data->requires, get_bloginfo( 'version' ), '<=' ) && version_compare( $cached_data->requires_php, PHP_VERSION, '<' ) ) {
                $response = new \stdClass();
                $response->slug = $this->plugin_slug;
                $response->plugin = "{$this->plugin_slug}/{$this->plugin_slug}.php";
                $response->new_version = $cached_data->version;
                $response->tested = $cached_data->tested;
                $response->package = $cached_data->download_url;
                $transient->response[ $response->plugin ] = $response;
            }
        
            return $transient;
        }


        /**
         * Purge cache on update plugin
         * 
         * @since 1.0.0
         * @return void
         * @package MeuMouse.com
         */
        public function purge( $upgrader, $options ) {
            if ( $this->cache_allowed && 'update' === $options['action'] && 'plugin' === $options[ 'type' ] ) {
                delete_transient( $this->info_cache_key );
                delete_transient( $this->update_cache_key );
            }
        }

    }
}

Flexify_Checkout_Updater::get_instance();