=== Flux Checkout for WooCommerce ===
Contributors: iconicwp
Requires at least: 4.7.4
Tested up to: 6.2