<?php
/**
 * Template for empty cart.
 *
 * @package Iconic_Flexify
 */

?>

<div class="flexify-empty-cart">
	<div class="flexify-empty-cart__wrap">
		<div class="flexify-empty-cart__icon-border">
			<div class="flexify-empty-cart__icon"></div>
		</div>
		<div class="flexify-empty-cart__text">
			<p><?php esc_html_e( 'Your cart is empty, taking you back to the shop...', 'flexify-checkout' ); ?></p>
		</div>
		<div class="flexify-empty-cart__button">
			<a class="flexify-button flexify-button--reverse flexify-button--emptycart" href="<?php echo esc_url( Iconic_Flexify_Helpers::get_shop_page_url() ); ?>"><?php esc_html_e( 'Return to shop', 'flexify-checkout' ); ?></a>
		</div>
	</div>
</div>

