<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Class for load API and backend settings
 * 
 * @package MeuMouse.com
 * @version 1.0.0
 */
class Flexify_Checkout_Autoloader {

	public $flexify_checkout_settings = array();
  public $responseObj;
  public $licenseMessage;
  public $showMessage;
  
  public function __construct() {
    add_action( 'plugins_loaded', array( $this, 'load_api_settings' ), 999 );

    // load plugin setting
    if ( empty( $this->flexify_checkout_settings ) ) {
      $this->flexify_checkout_settings = get_option( 'flexify_checkout_settings' );
    }
  }


  /**
   * Load API settings
   * 
   * @since 1.0.0
   */
  public function load_api_settings() {
    $this->responseObj = new stdClass();
    $this->responseObj->is_valid = false;

    $licenseKey = get_option('flexify_checkout_license_key', '');

    // Save settings on active license
    if ( current_user_can('manage_woocommerce') && isset( $_POST['flexify_checkout_active_license'] ) ) {
        update_option( 'flexify_checkout_license_key', $_POST );
        $licenseKey = !empty( $_POST['flexify_checkout_license_key'] ) ? $_POST['flexify_checkout_license_key'] : '';
        update_option( 'flexify_checkout_license_key', $licenseKey ) || add_option('flexify_checkout_license_key', $licenseKey );
        update_option( '_site_transient_update_plugins', '' );

        $activateLicense = true;
    }

    // Save settings on deactive license, or remove license status if it is invalid
    if ( current_user_can('manage_woocommerce') && ( isset( $_POST['flexify_checkout_deactive_license'] ) || get_option('flexify_checkout_license_status') == 'invalid' )) {
        if ( Flexify_Checkout_Api::RemoveLicenseKey( __FILE__, $message ) ) {
          update_option( 'flexify_checkout_license_status', 'invalid' );
          delete_option( 'flexify_checkout_license_key' );
          update_option( '_site_transient_update_plugins', '' );

          $deactivateLicense = true;
        }
    }

    // Check on the server if the license is valid and update responses and options
    if ( Flexify_Checkout_Api::CheckWPPlugin( $licenseKey, $this->licenseMessage, $this->responseObj, __FILE__ ) ) {
        update_option( 'flexify_checkout_license_status', 'valid' );
        include_once FLEXIFY_CHECKOUT_PATH . 'inc/classes/class-flexify-checkout-updater.php';
    } else {
        if ( !empty( $licenseKey ) && !empty( $this->licenseMessage ) ) {
            update_option( 'flexify_checkout_license_status', 'invalid' );
            $this->showMessage = true;
        }
    }
  }


  /**
	 * Plugin default settings
   * 
	 * @return array
	 * @since 1.0.0
	 * @access public
	 */
	public $default_settings = array(
    'enable_flexify_checkout' => 'yes',
    'enable_company_field' => 'no',
    'enable_street_number_field' => 'yes',
    'enable_back_to_shop_button' => 'no',
    'enable_skip_cart_page' => 'no',
    'enable_terms_is_checked_default' => 'yes',
    'enable_aditional_notes' => 'no',
    'enable_optimize_for_digital_products' => 'no',
    'enable_link_image_products' => 'no',
    'enable_fill_address' => 'yes',
    'enable_add_remove_products' => 'yes',
    'enable_ddi_phone_field' => 'no',
    'enable_hide_coupon_code_field' => 'no',
    'enable_auto_apply_coupon_code' => 'no',
    'enable_assign_guest_orders' => 'yes',
    'message_for_existing_user' => 'display_popup',
    'enable_inter_bank_pix_api' => 'no',
    'enable_inter_bank_ticket_api' => 'no',
    'checkout_header_type' => 'logo',
    'header_width_image_checkout' => '200',
    'unit_header_width_image_checkout' => 'px',
    'text_brand_checkout_header' => 'Checkout',
    'set_primary_color' => '#141D26',
    'set_primary_color_on_hover' => '#33404D',
    'set_placeholder_color' => '#33404D',
    'flexify_checkout_theme' => 'modern',
  );


  /**
	 * Function for get plugin general settings
	 * 
	 * @return string 
	 * @since 1.0.0
	 * @access public
	 */
	public function getSetting( $key ) {
    if ( ! empty( $this->flexify_checkout_settings) && isset( $this->flexify_checkout_settings[ $key ] ) ) {
      return $this->flexify_checkout_settings[ $key ];
    }

    if ( isset( $this->default_settings[ $key ] ) ) {
      return $this->default_settings[ $key ];
    }

    return false;
  }
  
}

new Flexify_Checkout_Autoloader();