<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Class to automatically load classes for compatibility checker
 *
 * @since 1.0.0
 * @package MeuMouse.com
 */

if ( class_exists( 'Flexify_Checkout_Compat_Autoloader' ) ) {
	return;
}

/**
 * Flexify_Checkout_Compat_Autoloader.
 *
 * @class    Flexify_Checkout_Compat_Autoloader
 * @version  1.0.1
 */
class Flexify_Checkout_Compat_Autoloader {
	/**
	 * Single instance of the Flexify_Checkout_Compat_Autoloader object.
	 *
	 * @var Flexify_Checkout_Compat_Autoloader
	 */
	public static $single_instance = null;

	/**
	 * Class args.
	 *
	 * @var array
	 */
	public static $args = array();

	/**
	 * Creates/returns the single instance Flexify_Checkout_Compat_Autoloader object.
	 *
	 * @param array $args Arguments.
	 *
	 * @return Flexify_Checkout_Compat_Autoloader
	 */
	public static function run( $args = array() ) {
		if ( null === self::$single_instance ) {
			self::$args = $args;
			self::$single_instance = new self();
		}

		return self::$single_instance;
	}

	/**
	 * Construct.
	 */
	private function __construct() {
		spl_autoload_register( array( __CLASS__, 'autoload' ) );
	}

	/**
	 * Autoloader
	 *
	 * Classes should reside within /inc and follow the format of
	 * Iconic_The_Name ~ class-the-name.php or {{class-prefix}}The_Name ~ class-the-name.php
	 *
	 * @param string $class_name Class Name.
	 */
	private static function autoload( $class_name ) {
		/**
		 * If the class being requested does not start with our prefix,
		 * we know it's not one in our project
		 */
		if ( 0 !== strpos( $class_name, self::$args['prefix'] ) ) {
			return;
		}

		$file_name = strtolower(
			str_replace(
				array( self::$args['prefix'], '_' ),
				array( '', '-' ),
				$class_name
			)
		);

		$file = self::$args['inc_path'] . 'class-' . $file_name . '.php';

		// Include found file.
		if ( file_exists( $file ) ) {
			require $file;

			return;
		}
	}
}
