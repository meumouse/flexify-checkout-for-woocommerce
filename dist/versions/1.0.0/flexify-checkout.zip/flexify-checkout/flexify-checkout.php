<?php

/**
 * Plugin Name: 			Flexify Checkout
 * Description: 			Extensão que otimiza a finalização de compra em multi etapas para lojas WooCommerce.
 * Plugin URI: 				https://meumouse.com/plugins/flexify-checkout/
 * Author: 					MeuMouse.com
 * Author URI: 				https://meumouse.com/
 * Version: 				1.0.0
 * WC requires at least: 	6.0.0
 * WC tested up to: 		8.0.2
 * Requires PHP: 			7.2
 * Tested up to:      		6.3
 * Text Domain: 			flexify-checkout
 * Domain Path: 			/languages
 * License: 				GPL2
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit; }

// Define FLEXIFY_CHECKOUT_PLUGIN_FILE.
if ( ! defined( 'FLEXIFY_CHECKOUT_PLUGIN_FILE' ) ) {
	define( 'FLEXIFY_CHECKOUT_PLUGIN_FILE', __FILE__ );
}

if ( ! class_exists( 'Flexify_Checkout' ) ) {
  
/**
 * Main Flexify_Checkout Class
 *
 * @class Flexify_Checkout
 * @version 1.0.0
 * @since 1.0.0
 * @package MeuMouse.com
 */
final class Flexify_Checkout {

		/**
		 * Flexify_Checkout The single instance of Flexify_Checkout.
		 *
		 * @var object
		 * @since 1.0.0
		 */
		private static $instance = null;

		/**
		 * The token
		 *
		 * @var string
		 * @since 1.0.0
		 */
		public $token;

		/**
		 * The version number
		 *
		 * @var string
		 * @since 1.0.0
		 */
		public $version;

		/**
		 * Constructor function.
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function __construct() {
			$this->token = 'flexify-checkout';
			$this->version = '1.0.0';
			
			add_action( 'plugins_loaded', array( $this, 'flexify_checkout_load_checker' ), 5 );
		}
		
		public function flexify_checkout_load_checker() {
			if ( !function_exists( 'is_plugin_active' ) ) {
				include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
			}

			// Display notice if PHP version is bottom 7.2
			if ( version_compare( phpversion(), '7.2', '<' ) ) {
				add_action( 'admin_notices', array( $this, 'flexify_checkout_php_version_notice' ) );
				return;
			}
		
			// check if WooCommerce is active
			if ( is_plugin_active( 'woocommerce/woocommerce.php' ) ) {
				add_action( 'init', array( $this, 'load_plugin_textdomain' ), -1 );
				add_action( 'plugins_loaded', array( $this, 'setup_constants' ), 15 );
				add_action( 'plugins_loaded', array( $this, 'setup_includes' ), 20 );
			//	add_action( 'plugins_loaded', array( $this, 'flexify_checkout_update_checker' ), 30 );
				add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), array( $this, 'flexify_checkout_plugin_links' ), 10, 4 );

			} else {
				deactivate_plugins( 'flexify-checkout/flexify-checkout.php' );
				add_action( 'admin_notices', array( $this, 'flexify_checkout_wc_deactivate_notice' ) );
			}

			// display notice if WooCommerce version is bottom 6.0
			if ( is_plugin_active( 'woocommerce/woocommerce.php' ) && version_compare( WC_VERSION, '6.0', '<' ) ) {
				add_action( 'admin_notices', array( $this, 'flexify_checkout_wc_version_notice' ) );
				return;
			}
		}

		/**
		 * Main Flexify_Checkout Instance
		 *
		 * Ensures only one instance of Flexify_Checkout is loaded or can be loaded.
		 *
		 * @since 1.0.0
		 * @static
		 * @see Flexify_Checkout()
		 * @return Main Flexify_Checkout instance
		 */
		public static function instance() {
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		/**
		 * Setup plugin constants
		 *
		 * @since  1.0.0
		 * @return void
		 */
		public function setup_constants() {

			// Plugin Folder Path.
			if ( ! defined( 'FLEXIFY_CHECKOUT_DIR' ) ) {
				define( 'FLEXIFY_CHECKOUT_DIR', plugin_dir_path( __FILE__ ) );
			}

			// Plugin Folder URL.
			if ( ! defined( 'FLEXIFY_CHECKOUT_URL' ) ) {
				define( 'FLEXIFY_CHECKOUT_URL', plugin_dir_url( __FILE__ ) );
			}

			// Plugin Root File.
			if ( ! defined( 'FLEXIFY_CHECKOUT_FILE' ) ) {
				define( 'FLEXIFY_CHECKOUT_FILE', __FILE__ );
			}

			$this->define( 'FLEXIFY_CHECKOUT_ABSPATH', dirname( FLEXIFY_CHECKOUT_FILE ) . '/' );
			$this->define( 'FLEXIFY_CHECKOUT_VERSION', $this->version );
		}

		/**
		 * Define constant if not already set.
		 *
		 * @param string      $name  Constant name.
		 * @param string|bool $value Constant value.
		 */
		private function define( $name, $value ) {
			if ( ! defined( $name ) ) {
				define( $name, $value );
			}
		}

		/**
		 * What type of request is this?
		 *
		 * @param  string $type admin, ajax, cron or wciend.
		 * @return bool
		 */
		private function is_request( $type ) {
			switch ( $type ) {
				case 'admin':
					return is_admin();
				case 'ajax':
					return defined( 'DOING_AJAX' );
				case 'cron':
					return defined( 'DOING_CRON' );
			}
		}

		/**
		 * Include required files
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function setup_includes() {

			/**
			 * Class init plugin
			 * 
			 * @since 1.0.0
			 */
			include_once FLEXIFY_CHECKOUT_DIR . 'includes/class-flexify-checkout-autoloader.php';

			/**
			 * Admin options
			 * 
			 * @since 1.0.0
			 */
			include_once FLEXIFY_CHECKOUT_DIR . 'includes/admin/class-flexify-checkout-admin-options.php';

			/**
			 * Load API settings
			 * 
			 * @since 1.0.0
			 */
			require_once FLEXIFY_CHECKOUT_DIR . 'includes/classes/class-flexify-checkout-api.php';	
		}

		/**
		 * WooCommerce version notice
		 */
		public function flexify_checkout_wc_version_notice() {
			echo '<div class="notice is-dismissible error">
					<p>' . __( '<strong>Flexify Checkout</strong> requer a versão do WooCommerce 6.0 ou maior. Faça a atualização do plugin WooCommerce.', 'flexify-checkout' ) . '</p>
				</div>';
		}

		/**
		 * Notice if WooCommerce is deactivate
		 */
		public function flexify_checkout_wc_deactivate_notice() {
			if ( !current_user_can( 'install_plugins' ) ) { return; }

			echo '<div class="notice is-dismissible error">
					<p>' . __( '<strong>Flexify Checkout</strong> requer que <strong>WooCommerce</strong> esteja instalado e ativado.', 'flexify-checkout' ) . '</p>
				</div>';
		}

		/**
		 * PHP version notice
		 */
		public function flexify_checkout_php_version_notice() {
			echo '<div class="notice is-dismissible error">
					<p>' . __( '<strong>Flexify Checkout</strong> requer a versão do PHP 7.2 ou maior. Contate o suporte da sua hospedagem para realizar a atualização.', 'flexify-checkout' ) . '</p>
				</div>';
		}

		/**
		 * Plugin action links
		 * 
		 * @since 1.0.0
		 * @return array
		 */
		public function flexify_checkout_plugin_links( $action_links ) {
			$plugins_links = array(
				'<a href="' . admin_url( 'admin.php?page=flexify-checkout' ) . '">'. __( 'Configurar', 'flexify-checkout' ) .'</a>',
				'<a href="https://meumouse.com/docs/plugins/parcelas-customizadas-para-woocommerce/" target="_blank">'. __( 'Ajuda', 'flexify-checkout' ) .'</a>'
			);

			return array_merge( $plugins_links, $action_links );
		}

		/**
		 * Plugin update checker
		 * 
		 * @since 1.0.0
		 */
		public function flexify_checkout_update_checker(){
			require FLEXIFY_CHECKOUT_DIR .'core/update-checker/plugin-update-checker.php';
			$myUpdateChecker = Puc_v4_Factory::buildUpdateChecker( 'https://raw.githubusercontent.com/meumouse/flexify-checkout/main/update-checker.json', __FILE__, 'flexify-checkout' );
		}

		/**
		 * Load the plugin text domain for translation.
		 */
		public static function load_plugin_textdomain() {
			load_plugin_textdomain( 'flexify-checkout', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
		}

		/**
		 * Get the plugin url.
		 *
		 * @return string
		 */
		public function plugin_url() {
			return untrailingslashit( plugins_url( '/', FLEXIFY_CHECKOUT_PLUGIN_FILE ) );
		}

		/**
		 * Cloning is forbidden.
		 *
		 * @since 1.0.0
		 */
		public function __clone() {
			_doing_it_wrong( __FUNCTION__, esc_html__( 'Trapaceando?', 'flexify-checkout' ), '1.0.0' );
		}

		/**
		 * Unserializing instances of this class is forbidden.
		 *
		 * @since 1.0.0
		 */
		public function __wakeup() {
			_doing_it_wrong( __FUNCTION__, esc_html__( 'Trapaceando?', 'flexify-checkout' ), '1.0.0' );
		}

	}
}

/**
 * Returns the main instance of Flexify_Checkout to prevent the need to use globals.
 *
 * @since  1.0.0
 * @return object Flexify_Checkout
 */
function Flexify_Checkout() { //phpcs:ignore WordPress.NamingConventions.ValidFunctionName.FunctionNameInvalid
	return Flexify_Checkout::instance();
}

/**
 * Initialise the plugin
 */
Flexify_Checkout();