<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
  exit; }

class Flexify_Checkout_Admin_Options extends Flexify_Checkout_Autoloader {

  /**
   * Flexify_Checkout_Admin constructor.
   *
   * @since 1.0.0
   * @access public
   */
  public function __construct() {
    parent::__construct();
    $options = get_option( 'flexify-checkout-setting' );

    add_action( 'admin_menu', array( $this, 'flexify_checkout_admin_menu' ) );
    add_action( 'admin_enqueue_scripts', array( $this, 'flexify_checkout_admin_scripts' ) );
    add_action( 'wp_ajax_flexify_checkout_ajax_save_options', array( $this, 'flexify_checkout_ajax_save_options_callback' ) );
    add_action( 'wp_ajax_nopriv_flexify_checkout_ajax_save_options', array( $this, 'flexify_checkout_ajax_save_options_callback' ) );
  }

  /**
   * Function for create submenu in WooCommerce
   * 
   * @since 1.0.0
   * @access public
   * @return array
   */
  public function flexify_checkout_admin_menu() {
    add_submenu_page(
      'woocommerce', // parent page slug
      esc_html__( 'Flexify Checkout', 'flexify-checkout'), // page title
      esc_html__( 'Flexify Checkout', 'flexify-checkout'), // submenu title
      'manage_woocommerce', // user capabilities
      'flexify-checkout', // page slug
      array( $this, 'flexify_checkout_settings_page' ), // public function for print content page
    );
  }


  /**
   * Plugin general setting page and save options
   * 
   * @since 1.0.0
   * @access public
   */
  public function flexify_checkout_settings_page() {
  //  global $options, $discountSettings, $activateLicense, $deactivateLicense;
    
    $settingSaves = false;
    $activateLicense = false;
    $deactivateLicense = false;
    $settings_array = array();

    // Save global options
    if( current_user_can( 'manage_woocommerce' ) && isset( $_POST[ 'save_settings' ] ) ) {
      update_option( 'flexify-checkout-setting', $_POST );
      $this->flexify_checkout_settings = $_POST;

      $settingSaves = true;
    }

    // Display notification on active license
    if( isset( $_POST[ 'active_license' ] ) && $this->responseObj->is_valid ) {
      $activateLicense = true;
    }

    // Display notification on deative license
    if( isset( $_POST[ 'deactive_license' ] ) ) {
      delete_option( 'flexify_checkout_license_key' );
      $deactivateLicense = true;
    }

    $options = get_option( 'flexify-checkout-setting' );

    include_once FLEXIFY_CHECKOUT_DIR . 'includes/admin/settings.php';
  }


  /**
   * Enqueue admin scripts in page settings only
   * 
   * @since 1.0.0
   * @access public
   * @return void
   */
  public function flexify_checkout_admin_scripts() {
    $url = $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
    $version = Flexify_Checkout()->version;

    if (false !== strpos($url, 'admin.php?page=flexify-checkout')) {
        wp_enqueue_script('flexify-checkout-admin-scripts', FLEXIFY_CHECKOUT_URL . 'assets/js/flexify-checkout-admin-scripts.js', array('jquery'), $version);
        wp_enqueue_style('flexify-checkout-admin-styles', FLEXIFY_CHECKOUT_URL . 'assets/css/flexify-checkout-admin-styles.css', array(), $version);
    
        wp_localize_script( 'flexify-checkout-admin-scripts', 'flexify_checkout_params', array(
          'ajax_url' => admin_url( 'admin-ajax.php' ),
        ) );
    }
  }


  /**
   * Save options in AJAX
   * 
   * @since 1.0.0
   * @return void
   * @package MeuMouse.com
   */
  public function flexify_checkout_ajax_save_options_callback() {
      if ( isset( $_POST['form_data'] ) ) {
          parse_str( $_POST['form_data'], $form_data ); // convert serialized data in array
          update_option( 'flexify-checkout-setting', $form_data ); // save options

          echo 'success'; // send response
      }

      wp_die();
  }

}

new Flexify_Checkout_Admin_Options();