<?php

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit; } ?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">

<div class="d-flex">
    <h1 class="flexify-checkout-admin-section-tile"><?php echo get_admin_page_title() ?></h1>
    <span class="badge bg-translucent-primary rounded-pill fs-sm <?php if ( ! $this->responseObj->is_valid ) { echo 'd-none';} ?>" style="margin: 2rem 0.5rem 0;"><?php echo esc_html__( 'Pro' ) ?></span>
</div>

<div class="flexify-checkout-admin-title-description">
    <p><?php echo esc_html__( 'Configure abaixo o parcelamento, descontos, juros, estilos e entre outras opções disponíveis. Se precisar de ajuda para configurar, acesse nossa', 'flexify-checkout' ) ?>
        <a class="fancy-link" href="https://meumouse.com/docs/plugins/parcelas-customizadas-para-woocommerce/" target="_blank"><?php echo esc_html__( 'Central de ajuda', 'flexify-checkout' ) ?></a>
    </p>
    <?php
        if ( class_exists('WC_PagSeguro') || class_exists('PagSeguro_Internacional__WooCommerce') || class_exists( 'WC_PagSeguro_Parceled' ) ) {
            ?>
                <span class="flexify-checkout-description"><?php echo __( 'O PagSeguro utiliza fator de multiplicação para calcular o juros.', 'flexify-checkout' ) ?></span>
                <a class="fancy-link" href="https://meumouse.com/docs/plugins/parcelas-customizadas-para-woocommerce/#convert-fee" target="__blank"><?php echo __( 'Como converter fator de multiplicação para juros.', 'flexify-checkout' ) ?></a>
            <?php
        }
    ?>
</div>

<div class="toast updated-option-notice-flexify-checkout">
    <div class="toast-header bg-success text-white">
        <i class="fa-regular fa-circle-check me-3"></i>
        <span class="me-auto"><?php _e( 'Salvo com sucesso', 'flexify-checkout' ); ?></span>
        <button class="btn-close btn-close-white ms-2 hide-toast" type="button" data-bs-dismiss="toast" aria-label="Close"></button>
    </div>
    <div class="toast-body"><?php _e( 'As configurações foram atualizadas!', 'flexify-checkout' ); ?></div>
</div>

<?php

    if( $activateLicense === true) { ?>
        <div class="toast update-notice-flexify-checkout">
            <div class="toast-header bg-success text-white">
                <i class="fa-regular fa-circle-check me-3"></i>
                <span class="me-auto"><?php _e( 'Licença ativada com sucesso!', 'flexify-checkout' ); ?></span>
                <button class="btn-close btn-close-white ms-2 hide-toast" type="button" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            <div class="toast-body"><?php _e( 'Todos os recursos da versão Pro agora estão ativos!', 'flexify-checkout' ); ?></div>
        </div>
        <?php
    }

    if( $deactivateLicense === true) { ?>
        <div class="toast toast-warning update-notice-flexify-checkout">
            <div class="toast-header bg-warning text-white">
                <i class="fa-regular fa-circle-check me-3"></i>
                <span class="me-auto"><?php _e( 'A licença foi desativada', 'flexify-checkout' ); ?></span>
                <button class="btn-close btn-close-white ms-2 hide-toast" type="button" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            <div class="toast-body"><?php _e( 'Todos os recursos da versão Pro agora estão desativados!', 'flexify-checkout' ); ?></div>
        </div>
        <?php
    }

    if( !empty( $this->showMessage ) && !empty( $this->licenseMessage ) ) { ?>
        <div class="toast toast-danger update-notice-flexify-checkout">
            <div class="toast-header bg-danger text-white">
                <i class="fa-regular fa-circle-check me-3"></i>
                <span class="me-auto"><?php _e( 'Ops! Ocorreu um erro.', 'flexify-checkout' ); ?></span>
                <button class="btn-close btn-close-white ms-2 hide-toast" type="button" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            <div class="toast-body"><?php _e( $this->licenseMessage, 'flexify-checkout' ); ?></div>
        </div>
        <?php
    }

    settings_errors(); ?>

<div class="flexify-checkout-wrapper">
    <div class="nav-tab-wrapper flexify-checkout-tab-wrapper">
        <a href="#general-settings" class="nav-tab nav-tab-active"><?php echo esc_html__( 'Geral', 'flexify-checkout' ) ?></a>
        <a href="#text-settings" class="nav-tab "><?php echo esc_html__( 'Textos', 'flexify-checkout' ) ?></a>
        <a href="#discount-settings" class="nav-tab "><?php echo esc_html__( 'Descontos', 'flexify-checkout' ) ?></a>
        <a href="#interests-settings" class="nav-tab "><?php echo esc_html__( 'Juros', 'flexify-checkout' ) ?></a>
        <a href="#payment-form-settings" class="nav-tab "><?php echo esc_html__( 'Formas de pagamento', 'flexify-checkout' ) ?></a>
        <a href="#design-settings" class="nav-tab "><?php echo esc_html__( 'Personalizar', 'flexify-checkout' ) ?></a>
        <a href="#about-settings" class="nav-tab "><?php echo esc_html__( 'Sobre', 'flexify-checkout' ) ?></a>
    </div>

    <form method="post" action="" class="flexify-checkout-form" name="flexify-checkout">
        <input type="hidden" name="flexify-checkout" value="1"/>
        <?php
        include_once FLEXIFY_CHECKOUT_DIR . 'includes/admin/tabs/options.php';
        include_once FLEXIFY_CHECKOUT_DIR . 'includes/admin/tabs/design.php';
        include_once FLEXIFY_CHECKOUT_DIR . 'includes/admin/tabs/about.php';
        ?>
    </form>