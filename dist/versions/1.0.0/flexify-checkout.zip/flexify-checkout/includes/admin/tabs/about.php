<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
  exit; } ?>

<div id="about-settings" class="nav-content ">
  <table class="form-table">
	<tr>
		<td class="d-grid">
			<h3 class="mb-4"><?php esc_html_e( 'Informações sobre a licença:', 'flexify-checkout' ); ?></h3>
			<span class="mb-2"><?php echo esc_html__( 'Status da licença:', 'flexify-checkout' ) ?>
				<?php if ( $this->responseObj->is_valid ) : ?>
					<span class="badge bg-translucent-success rounded-pill"><?php _e(  'Válida', 'flexify-checkout' );?></span>
				<?php else : ?>
					<span class="badge bg-translucent-danger rounded-pill"><?php _e(  'Inválida', 'flexify-checkout' );?></span>
				<?php endif; ?>
			</span>
			<span class="mb-2"><?php echo esc_html__( 'Recursos:', 'flexify-checkout' ) ?>
				<?php if ( $this->responseObj->is_valid ) : ?>
					<span class="badge bg-translucent-primary rounded-pill"><?php _e(  'Pro', 'flexify-checkout' );?></span>
				<?php else : ?>
					<span class="badge bg-translucent-warning rounded-pill"><?php _e(  'Grátis', 'flexify-checkout' );?></span>
				<?php endif; ?>
			</span>
			<a class="btn btn-primary my-4 pulsating-button <?php if ( $this->responseObj->is_valid ) { echo 'd-none';} ?>" href="https://meumouse.com/plugins/parcelas-customizadas-para-woocommerce/?utm_source=wordpress&utm_medium=plugins-list&utm_campaign=wci" target="_blank">
				<i class="fa-solid fa-key me-1"></i>
				<span><?php _e(  'Comprar licença', 'flexify-checkout' );?></span>
			</a>
			<span class="mb-2 <?php if ( ! $this->responseObj->is_valid ) { echo 'd-none';} ?>"><?php echo esc_html__( 'Tipo da licença:', 'flexify-checkout' ) ?>
				<span><?php if (isset( $this->responseObj->license_title ) ) { echo $this->responseObj->license_title; } ?></span>
			</span>
			<span class="mb-2 <?php if ( ! $this->responseObj->is_valid ) { echo 'd-none';} ?>"><?php echo esc_html__( 'Sua chave de licença:', 'flexify-checkout' ) ?>
				<span>
					<?php 
					if (isset( $this->responseObj->license_key ) ) {
						echo esc_attr( substr( $this->responseObj->license_key, 0, 9). "XXXXXXXX-XXXXXXXX".substr( $this->responseObj->license_key,-9) );
					} else {
						echo __(  'Chave da licença não disponível', 'flexify-checkout' );
					}
					?>
				</span>
			</span>
		</td>
	</tr>
    <tr class="<?php if ( $this->responseObj->is_valid ) { echo 'd-none';} ?>">
      <td class="w-75">
	  	<span id="insert-license-info" class="bg-translucent-danger rounded-2 p-2 mb-4 <?php if ( $this->responseObj->is_valid ) { echo 'd-none';} ?>"><?php echo esc_html__( 'Informe sua licença abaixo para desbloquear todos os recursos.', 'flexify-checkout' ) ?></span>
        <span class="form-label d-block mt-2"><?php echo esc_html__( 'Código da licença', 'flexify-checkout' ) ?></span>
        <div class="input-group" style="width: 550px;">
			<input class="form-control" type="text" placeholder="XXXXXXXX-XXXXXXXX-XXXXXXXX-XXXXXXXX" id="license_key" name="license_key" size="50" value="<?php echo get_option( 'woo_custom_installments_license_key' ) ?>" />
			<button id="active_license" name="active_license" class="btn btn-primary button-loading <?php if ( $this->responseObj->is_valid ) { echo 'd-none';} ?>" type="submit">
				<span class="span-inside-button-loader"><?php esc_attr_e( 'Ativar licença', 'flexify-checkout' ); ?></span>
			</button>
		</div>
      </td>
    </tr>
	<tr class="d-none">
      <td class="w-75">
        <span class="form-label d-block"><?php echo esc_html__( 'E-mail vinculado à licença', 'flexify-checkout' ) ?></span>
        <input class="form-control mt-2" type="email" placeholder="exemplo@email.com" id="license_email" name="license_email" value="<?php echo get_option( 'woo_custom_installments_license_email' ) ?>" />
      </td>
    </tr>
	<tr class="<?php if ( ! $this->responseObj->is_valid ) { echo 'd-none';} ?>">
		<td>
			<button id="deactive_license" name="deactive_license" class="btn btn-sm btn-primary button-loading" type="submit">
				<span class="span-inside-button-loader"><?php esc_attr_e( 'Desativar licença', 'flexify-checkout' ); ?></span>
			</button>
		</td>
	</tr>
	<tr class="w-75 mt-5">
		<td>
			<h3 class="mt-0"><?php esc_html_e( 'Status do sistema:', 'flexify-checkout' ); ?></h3>
			<h4><?php esc_html_e( 'WordPress', 'flexify-checkout' ); ?></h4>
			<div class="d-flex mb-2">
				<span><?php esc_html_e( 'Versão do WordPress:', 'flexify-checkout' ); ?></span>
				<span class="ms-2"><?php echo esc_html( get_bloginfo( 'version' ) ); ?></span>
			</div>
			<div class="d-flex mb-2">
				<span><?php esc_html_e( 'WordPress Multisite:', 'flexify-checkout' ); ?></span>
				<span class="ms-2"><?php echo is_multisite() ? esc_html__( 'Sim', 'flexify-checkout' ) : esc_html__( 'Não', 'flexify-checkout' ); ?></span>
			</div>
			<div class="d-flex mb-2">
				<span><?php esc_html_e( 'Modo de depuração do WordPress:', 'flexify-checkout' ); ?></span>
				<span class="ms-2"><?php echo defined( 'WP_DEBUG' ) && WP_DEBUG ? esc_html__( 'Ativo', 'flexify-checkout' ) : esc_html__( 'Desativado', 'flexify-checkout' ); ?></span>
			</div>

			<h4><?php esc_html_e( 'WooCommerce', 'flexify-checkout' ); ?></h4>
			<div class="d-flex mb-2">
				<span><?php esc_html_e( 'Versão do WooCommerce:', 'flexify-checkout' ); ?></span>
				<span class="ms-2">
					<?php if( version_compare( WC_VERSION, '6.0', '<' ) ) : ?>
						<span class="badge bg-translucent-danger">
							<span>
								<?php echo esc_html( WC_VERSION ); ?>
							</span>
							<span>
								<?php esc_html_e( 'A versão mínima exigida do WooCommerce é 6.0', 'flexify-checkout' ); ?>
							</span>
						</span>
					<?php else : ?>
						<span class="badge bg-translucent-success">
							<?php echo esc_html( WC_VERSION ); ?>
						</span>
					<?php endif; ?>
				</span>
			</div>

			<h4><?php esc_html_e( 'Servidor', 'flexify-checkout' ); ?></h4>
			<div class="d-flex mb-2">
				<span><?php esc_html_e( 'Versão do PHP:', 'flexify-checkout' ); ?></span>
				<span class="ms-2">
					<?php if ( version_compare( PHP_VERSION, '7.2', '<' ) ) : ?>
						<span class="badge bg-translucent-danger">
							<span>
								<?php echo esc_html( PHP_VERSION ); ?>
							</span>
							<span>
								<?php esc_html_e( 'A versão mínima exigida do PHP é 7.2', 'flexify-checkout' ); ?>
							</span>
						</span>
					<?php else : ?>
						<span class="badge bg-translucent-success">
							<?php echo esc_html( PHP_VERSION ); ?>
						</span>
					<?php endif; ?>
				</span>
			</div>
			<div class="d-flex mb-2">
				<span><?php esc_html_e( 'DOMDocument:', 'flexify-checkout' ); ?></span>
				<span class="ms-2">
					<span>
						<?php if ( ! class_exists( 'DOMDocument' ) ) : ?>
							<span class="badge bg-translucent-danger">
								<?php esc_html_e( 'Não', 'flexify-checkout' ); ?>
							</span>
						<?php else : ?>
							<span class="badge bg-translucent-success">
								<?php esc_html_e( 'Sim', 'flexify-checkout' ); ?>
							</span>
						<?php endif; ?>
					</span>
				</span>
			</div>
			<div class="d-flex mb-2">
				<span><?php esc_html_e( 'Extensão cURL:', 'flexify-checkout' ); ?></span>
				<span class="ms-2">
					<span>
						<?php if ( !extension_loaded('curl') ) : ?>
							<span class="badge bg-translucent-danger">
								<?php esc_html_e( 'Não', 'flexify-checkout' ); ?>
							</span>
						<?php else : ?>
							<span class="badge bg-translucent-success">
								<?php esc_html_e( 'Sim', 'flexify-checkout' ); ?>
							</span>
						<?php endif; ?>
					</span>
				</span>
			</div>
			<?php if ( function_exists( 'ini_get' ) ) : ?>
				<div class="d-flex mb-2">
					<span>
						<?php $post_max_size = ini_get( 'post_max_size' ); ?>

						<?php esc_html_e( 'Tamanho máximo da postagem do PHP:', 'flexify-checkout' ); ?>
					</span>
					<span class="ms-2">
						<?php if ( wp_convert_hr_to_bytes( $post_max_size ) < 64000000 ) : ?>
							<span>
								<span class="badge bg-translucent-danger">
									<?php echo esc_html( $post_max_size ); ?>
								</span>
								<span>
									<?php esc_html_e( 'Valor mínimo recomendado é 64M', 'flexify-checkout' ); ?>
								</span>
							</span>
						<?php else : ?>
							<span class="badge bg-translucent-success">
								<?php echo esc_html( $post_max_size ); ?>
							</span>
						<?php endif; ?>
					</span>
				</div>
				<div class="d-flex mb-2">
					<span>
						<?php $max_execution_time = ini_get( 'max_execution_time' ); ?>
						<?php esc_html_e( 'Limite de tempo do PHP:', 'flexify-checkout' ); ?>
					</span>
					<span class="ms-2">
						<?php if ( $max_execution_time < 180 ) : ?>
							<span>
								<span class="badge bg-translucent-danger">
									<?php echo esc_html( $max_execution_time ); ?>
								</span>
								<span>
									<?php esc_html_e( 'Valor mínimo recomendado é 180', 'flexify-checkout' ); ?>
								</span>
							</span>
						<?php else : ?>
							<span class="badge bg-translucent-success">
								<?php echo esc_html( $max_execution_time ); ?>
							</span>
						<?php endif; ?>
					</span>
				</div>
				<div class="d-flex mb-2">
					<span>
						<?php $max_input_vars = ini_get( 'max_input_vars' ); ?>
						<?php esc_html_e( 'Variáveis máximas de entrada do PHP:', 'flexify-checkout' ); ?>
					</span>
					<span class="ms-2">
						<?php if ( $max_input_vars < 10000 ) : ?>
							<span>
								<span class="badge bg-translucent-danger">
									<?php echo esc_html( $max_input_vars ); ?>
								</span>
								<span>
									<?php esc_html_e( 'Valor mínimo recomendado é 10000', 'flexify-checkout' ); ?>
								</span>
							</span>
						<?php else : ?>
							<span class="badge bg-translucent-success">
								<?php echo esc_html( $max_input_vars ); ?>
							</span>
						<?php endif; ?>
					</span>
				</div>
				<div class="d-flex mb-2">
					<span>
						<?php $memory_limit = ini_get( 'memory_limit' ); ?>
						<?php esc_html_e( 'Limite de memória do PHP:', 'flexify-checkout' ); ?>
					</span>
					<span class="ms-2">
						<?php if ( wp_convert_hr_to_bytes( $memory_limit ) < 128000000 ) : ?>
							<span>
								<span class="badge bg-translucent-danger">
									<?php echo esc_html( $memory_limit ); ?>
								</span>
								<span>
									<?php esc_html_e( 'Valor mínimo recomendado é 128M', 'flexify-checkout' ); ?>
								</span>
							</span>
						<?php else : ?>
							<span class="badge bg-translucent-success">
								<?php echo esc_html( $memory_limit ); ?>
							</span>
						<?php endif; ?>
					</span>
				</div>
				<div class="d-flex mb-2">
					<span>
						<?php $upload_max_filesize = ini_get( 'upload_max_filesize' ); ?>
						<?php esc_html_e( 'Tamanho máximo de envio do PHP:', 'flexify-checkout' ); ?>
					</span>
					<span class="ms-2">
						<?php if ( wp_convert_hr_to_bytes( $upload_max_filesize ) < 64000000 ) : ?>
							<span>
								<span class="badge bg-translucent-danger">
									<?php echo esc_html( $upload_max_filesize ); ?>
								</span>
								<span>
									<?php esc_html_e( 'Valor mínimo recomendado é 64M', 'flexify-checkout' ); ?>
								</span>
							</span>
						<?php else : ?>
							<span class="badge bg-translucent-success">
								<?php echo esc_html( $upload_max_filesize ); ?>
							</span>
						<?php endif; ?>
					</span>
				</div>
				<div class="d-flex mb-2">
					<span><?php esc_html_e( 'Função PHP "file_get_content":', 'flexify-checkout' ); ?></span>
					<span class="ms-2">
						<?php if ( ! ini_get( 'allow_url_fopen' ) ) : ?>
							<span class="badge bg-translucent-danger">
								<?php esc_html_e( 'Desligado', 'flexify-checkout' ); ?>
							</span>
						<?php else : ?>
							<span class="badge bg-translucent-success">
								<?php esc_html_e( 'Ligado', 'flexify-checkout' ); ?>
							</span>
						<?php endif; ?>
					</span>
				</div>
			<?php endif; ?>
		</td>
		<tr>
			<td>
				<a class="btn btn-sm btn-outline-danger" target="_blank" href="https://meumouse.com/reportar-problemas/"><?php esc_html_e( 'Reportar problemas', 'flexify-checkout' ); ?></a>
			</td>
		</tr>
	</tr>
  </table>
</div>