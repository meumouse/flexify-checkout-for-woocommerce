<?php

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit; }

/**
 * Main class
 * 
 * @package MeuMouse.com
 * @version 1.0.0
 */
class Flexify_Checkout_Autoloader {

	public $flexify_checkout_settings = array();
  public $options = array();
  public $customFeeInstallments = array();
  public $plugin_file = __FILE__;
  public $responseObj;
  public $licenseMessage;
  public $showMessage = false;
  
  public function __construct() {
  //  global $wpdb, $options, $responseObj;

    add_action( 'plugins_loaded', array( $this, 'saveOptionsApi' ), 999 );
    add_action( 'plugins_loaded', array( $this, 'initApi' ), 999 );
    add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );

    // load plugin setting
    if( empty( $this->flexify_checkout_settings ) ) {
      $this->flexify_checkout_settings = get_option( 'flexify-checkout-setting' );
    }

  }


  /**
   * Load API settings
   * 
   * @since 1.0.0
   */
  public function initApi() {
    $this->responseObj = new stdClass();
    $this->responseObj->is_valid = false;

    $licenseKey = get_option( 'flexify_checkout_license_key', '');
    $licenseEmail = get_option( 'flexify_checkout_license_email', '');
    
    // Save settings on active license
    if( current_user_can( 'manage_woocommerce' ) && isset( $_POST[ 'active_license' ] ) ) {
      update_option( 'flexify_checkout_license_key', $_POST );
      $licenseKey = !empty( $_POST[ 'license_key' ] ) ? $_POST[ 'license_key' ] : "";
      $licenseEmail = !empty( $_POST[ 'license_email' ] ) ? $_POST[ 'license_email' ] : "";
      update_option( 'flexify_checkout_license_key', $licenseKey ) || add_option( 'flexify_checkout_license_key', $licenseKey );
      update_option( 'flexify_checkout_license_email', $licenseEmail) || add_option( 'flexify_checkout_license_email', $licenseEmail );
      update_option( '_site_transient_update_plugins', '' );

      $activateLicense = true;
    }

    // Save settings on deactive license, or remove license if is invalid
    if( current_user_can( 'manage_woocommerce' ) && isset( $_POST[ 'deactive_license' ] ) || get_option( 'flexify_checkout_license_status' ) == 'invalid' ) {
      if( Flexify_Checkout_Api::RemoveLicenseKey( __FILE__, $message ) ) {
        update_option( 'flexify_checkout_license_key', '' ) || add_option( 'flexify_checkout_license_key', '' );
        update_option( '_site_transient_update_plugins', '');
        delete_option( 'flexify_checkout_license_status' );

        $deactivateLicense = true;
      }
    }

    // check in the server if license is valid e update responses and options
    if( Flexify_Checkout_Api::CheckWPPlugin( $licenseKey, $licenseEmail, $this->licenseMessage, $this->responseObj, __FILE__ ) ) {
      update_option( 'flexify_checkout_license_status', 'valid' );
      $this->responseObj->is_valid = true;
      return;
    } else {
      if( !empty( $licenseKey ) && !empty( $this->licenseMessage ) ) {
        update_option( 'flexify_checkout_license_status', 'invalid' );
        $this->responseObj->is_valid = false;
        $this->showMessage = true;
      }
    }
    
  }


  public function saveOptionsApi() {
    // Save settings on active license
    if( current_user_can( 'manage_woocommerce' ) && isset( $_POST[ 'active_license' ] ) ) {
      update_option( 'flexify_checkout_license_key', $_POST );
      $licenseKey = ! empty( $_POST[ 'license_key' ] ) ? $_POST[ 'license_key' ] : "";
      $licenseEmail = ! empty( $_POST[ 'license_email' ] ) ? $_POST[ 'license_email' ] : "";
      update_option( 'flexify_checkout_license_key', $licenseKey ) || add_option( 'flexify_checkout_license_key', $licenseKey );
      update_option( 'flexify_checkout_license_email', $licenseEmail) || add_option( 'flexify_checkout_license_email', $licenseEmail );
      update_option( '_site_transient_update_plugins', '' );
      $activateLicense = true;
    }

    // Save settings on deactive license
    if( current_user_can( 'manage_woocommerce' ) && isset( $_POST[ 'deactive_license' ] ) ) {
      if( Flexify_Checkout_Api::RemoveLicenseKey( __FILE__, $message ) ) {
        update_option( 'flexify_checkout_license_key', '' ) || add_option( 'flexify_checkout_license_key', '' );
        update_option( '_site_transient_update_plugins', '');
        $deactivateLicense = true;
      }
    }
  }


  /**
	 * Plugin default settings
   * 
	 * @return array
	 * @since 1.0.0
	 * @access public
	 */
	public $default_settings = array(
    'string' => '0',
  );


  /**
	 * Function for get plugin general settings
	 * 
	 * @return string 
	 * @since 1.0.0
	 * @access public
	 */
	public function getSetting( $key ) {
    if( ! empty( $this->flexify_checkout_settings) && isset( $this->flexify_checkout_settings[ $key ] ) ) {
      return $this->flexify_checkout_settings[ $key ];
    }

    if( isset( $this->default_settings[ $key ] ) ) {
      return $this->default_settings[ $key ];
    }

    return false;
  }


  /**
   * Enqueue scripts and styles
   *
   * @return void
   * @since 1.0.0
   */
  public function enqueue_scripts() {
    $version = Flexify_Checkout()->version;

    wp_enqueue_script( 'flexify-checkout-front-scripts', FLEXIFY_CHECKOUT_URL . 'assets/js/flexify-checkout-front-scripts.js', array('jquery'), $version );
    wp_enqueue_style( 'flexify-checkout-front-styles', FLEXIFY_CHECKOUT_URL . 'assets/css/flexify-checkout-front-styles.css', array(), $version );
    wp_enqueue_script( 'font-awesome-lib', FLEXIFY_CHECKOUT_URL . 'assets/js/font-awesome.min.js', array(), '6.4.0' );
  }
  
}

new Flexify_Checkout_Autoloader();