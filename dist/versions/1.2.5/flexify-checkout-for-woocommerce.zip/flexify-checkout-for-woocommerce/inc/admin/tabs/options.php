<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

?>

<div id="general-settings" class="nav-content active">
   <table class="form-table">
      <tr>
         <th>
            <?php echo esc_html__( 'Ativar Flexify Checkout', 'flexify-checkout-for-woocommerce' ) ?>
            <span class="flexify-checkout-description"><?php echo esc_html__( 'Ative esta opção para carregar o modelo de finalização de compra Flexify Checkout.', 'flexify-checkout-for-woocommerce' ) ?></span>
         </th>
         <td>
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_flexify_checkout" name="enable_flexify_checkout" value="yes" <?php checked( $this->getSetting( 'enable_flexify_checkout') == 'yes' ); ?> />
            </div>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Ativar campo de Empresa', 'flexify-checkout-for-woocommerce' ) ?>
            <span class="flexify-checkout-description"><?php echo esc_html__( 'Ative esta opção para exibir o campo "Empresa" na finalização de compras.', 'flexify-checkout-for-woocommerce' ) ?></span>
         </th>
         <td>
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_company_field" name="enable_company_field" value="yes" <?php checked( $this->getSetting('enable_company_field') == 'yes' ); ?> />
            </div>
         </td>
      </tr>
   <!--   <tr>
         <th>
            <?php echo esc_html__( 'Adicionar campo de número da residência', 'flexify-checkout-for-woocommerce' ) ?>
            <span class="flexify-checkout-description"><?php echo esc_html__( 'Ative esta opção para separar o número da resiência do endereço.', 'flexify-checkout-for-woocommerce' ) ?></span>
         </th>
         <td>
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_street_number_field" name="enable_street_number_field" value="yes" <?php checked( $this->getSetting( 'enable_street_number_field') == 'yes' ); ?> />
            </div>
         </td>
      </tr> -->
      <tr>
         <th>
            <?php echo esc_html__( 'Mostrar botão Voltar à loja', 'flexify-checkout-for-woocommerce' ) ?>
            <span class="flexify-checkout-description"><?php echo esc_html__( 'Ative esta opção para exibir o botão "Voltar à loja" na primeira etapa de finalização de compra.', 'flexify-checkout-for-woocommerce' ) ?></span>
         </th>
         <td>
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_back_to_shop_button" name="enable_back_to_shop_button" value="yes" <?php checked( $this->getSetting('enable_back_to_shop_button') == 'yes' ); ?> />
            </div>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Pular página do carrinho', 'flexify-checkout-for-woocommerce' ) ?>
            <span class="flexify-checkout-description"><?php echo esc_html__( 'Ative esta opção para redirecionar o usuário da página de carrinho para a finalização de compra automaticamente.', 'flexify-checkout-for-woocommerce' ) ?></span>
         </th>
         <td>
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_skip_cart_page" name="enable_skip_cart_page" value="yes" <?php checked( $this->getSetting('enable_skip_cart_page') == 'yes' ); ?> />
            </div>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Termos e condições ativo por padrão', 'flexify-checkout-for-woocommerce' ) ?>
            <span class="flexify-checkout-description"><?php echo esc_html__( 'Ative esta opção para a opção de termos e condições da última etapa ficar ativa por padrão, caso exista uma página de termos e condições configurada.', 'flexify-checkout-for-woocommerce' ) ?></span>
         </th>
         <td>
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_terms_is_checked_default" name="enable_terms_is_checked_default" value="yes" <?php checked( $this->getSetting('enable_terms_is_checked_default') == 'yes' ); ?> />
            </div>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Mostrar observações adicionais', 'flexify-checkout-for-woocommerce' ) ?>
            <span class="flexify-checkout-description"><?php echo esc_html__( 'Ative esta opção para mostrar o campo de observações adicionais no pedido.', 'flexify-checkout-for-woocommerce' ) ?></span>
         </th>
         <td>
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_aditional_notes" name="enable_aditional_notes" value="yes" <?php checked( $this->getSetting('enable_aditional_notes') == 'yes' ); ?> />
            </div>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Otimizar para produtos digitais', 'flexify-checkout-for-woocommerce' ) ?>
            <span class="flexify-checkout-description"><?php echo esc_html__( 'Se ativo, os campos da finalização de compra serão reduzidos apenas para os essenciais para produtos digitais.', 'flexify-checkout-for-woocommerce' ) ?></span>
         </th>
         <td>
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_optimize_for_digital_products" name="enable_optimize_for_digital_products" value="yes" <?php checked( $this->getSetting('enable_optimize_for_digital_products') == 'yes' ); ?> />
            </div>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Tornar imagem de produtos clicáveis', 'flexify-checkout-for-woocommerce' ) ?>
            <span class="flexify-checkout-description"><?php echo esc_html__( 'Se ativo, as imagens de produtos que estão no carrinho serão clicáveis.', 'flexify-checkout-for-woocommerce' ) ?></span>
         </th>
         <td>
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_link_image_products" name="enable_link_image_products" value="yes" <?php checked( $this->getSetting('enable_link_image_products') == 'yes' ); ?> />
            </div>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Preencher endereço automaticamente', 'flexify-checkout-for-woocommerce' ) ?>
            <span class="flexify-checkout-description"><?php echo esc_html__( 'Se ativo, os campos de endereço, bairro, cidade e estado serão preenchidos automaticamente ao digitar o CEP.', 'flexify-checkout-for-woocommerce' ) ?></span>
         </th>
         <td>
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_fill_address" name="enable_fill_address" value="yes" <?php checked( $this->getSetting('enable_fill_address') == 'yes' ); ?> />
            </div>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Permitir adicionar e remover produtos', 'flexify-checkout-for-woocommerce' ) ?>
            <span class="flexify-checkout-description"><?php echo esc_html__( 'Se ativo, será exibido botões de adição e exclusão de unidades na finalização de compras.', 'flexify-checkout-for-woocommerce' ) ?></span>
         </th>
         <td>
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_add_remove_products" name="enable_add_remove_products" value="yes" <?php checked( $this->getSetting('enable_add_remove_products') == 'yes' ); ?> />
            </div>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Ativar seletor de país em número de telefone', 'flexify-checkout-for-woocommerce' ) ?>
            <span class="flexify-checkout-description"><?php echo esc_html__( 'Se ativo, irá exibir o seletor de países no campo de número de telefone. Ideal se você vende também para outros países.', 'flexify-checkout-for-woocommerce' ) ?></span>
         </th>
         <td>
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_ddi_phone_field" name="enable_ddi_phone_field" value="yes" <?php checked( $this->getSetting('enable_ddi_phone_field') == 'yes' ); ?> />
            </div>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Ocultar campo de cupom de desconto', 'flexify-checkout-for-woocommerce' ) ?>
            <span class="flexify-checkout-description"><?php echo esc_html__( 'Quando ativado, o campo do cupom não será exibido aos usuários e eles não poderão inserir um código de cupom. No entanto, você pode aplicar um cupom automaticamente.', 'flexify-checkout-for-woocommerce' ) ?></span>
         </th>
         <td>
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_hide_coupon_code_field" name="enable_hide_coupon_code_field" value="yes" <?php checked( $this->getSetting('enable_hide_coupon_code_field') == 'yes' ); ?> />
            </div>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Aplicar cupom de desconto automaticamente', 'flexify-checkout-for-woocommerce' ) ?>
            <span class="flexify-checkout-description"><?php echo esc_html__( 'Ative esta opção para informar um cupom de desconto para ser aplicado automaticamente na finalização de compra.', 'flexify-checkout-for-woocommerce' ) ?></span>
         </th>
         <td>
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_auto_apply_coupon_code" name="enable_auto_apply_coupon_code" value="yes" <?php checked( $this->getSetting('enable_auto_apply_coupon_code') == 'yes' ); ?> />
            </div>
         </td>
      </tr>
      <tr class="show-coupon-code-enabled">
         <th>
            <?php echo esc_html__( 'Código do cupom de desconto', 'flexify-checkout-for-woocommerce' ) ?>
            <span class="flexify-checkout-description"><?php echo esc_html__( 'Informe o código do cupom de desconto que será aplicado automaticamente na finalização de compra.', 'flexify-checkout-for-woocommerce' ) ?></span>
         </th>
         <td>
            <input type="text" name="coupon_code_for_auto_apply" class="form-control" placeholder="<?php echo esc_html__( 'CUPOMDEDESCONTO', 'flexify-checkout-for-woocommerce' ) ?>" value="<?php echo $this->getSetting( 'coupon_code_for_auto_apply' ) ?>"/>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Atribuir pedidos de usuários convidados', 'flexify-checkout-for-woocommerce' ) ?>
            <span class="flexify-checkout-description"><?php echo esc_html__( 'Ative esta opção para que pedidos de usuários convidados na finalização de compra sejam atribuídos a usuários existentes.', 'flexify-checkout-for-woocommerce' ) ?></span>
         </th>
         <td>
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_assign_guest_orders" name="enable_assign_guest_orders" value="yes" <?php checked( $this->getSetting('enable_assign_guest_orders') == 'yes' ); ?> />
            </div>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Informar usuário existente', 'flexify-checkout-for-woocommerce' ) ?>
            <span class="flexify-checkout-description"><?php echo esc_html__( 'Selecione o formato da mensagem a usuários existentes.', 'flexify-checkout-for-woocommerce' ) ?></span>
         </th>
         <td>
            <select name="message_for_existing_user" class="form-select">
               <option value="display_popup" <?php echo ( $this->getSetting( 'message_for_existing_user' ) == 'display_popup' ) ? "selected=selected" : ""; ?>><?php echo esc_html__( 'Mostrar pop-up com mensagem para login (Padrão)', 'flexify-checkout-for-woocommerce' ) ?></option>
               <option value="display_message_inline" <?php echo ( $this->getSetting( 'message_for_existing_user' ) == 'display_message_inline' ) ? "selected=selected" : ""; ?>><?php echo esc_html__( 'Mostrar mensagem em linha', 'flexify-checkout-for-woocommerce' ) ?></option>
               <option value="dont_offer_login" <?php echo ( $this->getSetting( 'message_for_existing_user' ) == 'dont_offer_login' ) ? "selected=selected" : ""; ?>><?php echo esc_html__( 'Não mostrar mensagem de login', 'flexify-checkout-for-woocommerce' ) ?></option>
            </select>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Página de contato', 'flexify-checkout-for-woocommerce' ) ?>
            <span class="flexify-checkout-description"><?php echo esc_html__( 'Selecione a página de contato que será exibida aos clientes na finalização de compra.', 'flexify-checkout-for-woocommerce' ) ?></span>
         </th>
         <td>
         <select name="contact_page_thankyou" class="form-select">
            <?php
            $pages = get_pages();

            foreach ($pages as $page) {
               $selected = ( $this->getSetting( 'contact_page_thankyou' ) == esc_attr($page->ID) ) ? 'selected="selected"' : '';
               echo '<option value="'. esc_attr($page->ID) .'" ' . $selected . '>' . esc_html($page->post_title) . '</option>';
            }
            ?>
         </select>
         </td>
      </tr>
   </table>
</div>