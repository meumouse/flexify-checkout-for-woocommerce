(function ($) {
    "use strict";

	/**
	 * Activate tabs
	 * 
	 * @since 1.0.0
	 */
	jQuery( function($) {
		// Reads the index stored in localStorage, if it exists
		let activeTabIndex = localStorage.getItem('activeTabIndex');

		if (activeTabIndex === null) {
			// If it is null, activate the general tab
			$('.flexify-checkout-wrapper a.nav-tab[href="#general-settings"]').click();
		} else {
			$('.flexify-checkout-wrapper a.nav-tab').eq(activeTabIndex).click();
		}
	});
	  
	$(document).on('click', '.flexify-checkout-wrapper a.nav-tab', function() {
		// Stores the index of the active tab in localStorage
		let tabIndex = $(this).index();
		localStorage.setItem('activeTabIndex', tabIndex);
		
		let attrHref = $(this).attr('href');
		
		$('.flexify-checkout-wrapper a.nav-tab').removeClass('nav-tab-active');
		$('.flexify-checkout-form .nav-content').removeClass('active');
		$(this).addClass('nav-tab-active');
		$('.flexify-checkout-form').find(attrHref).addClass('active');
		
		return false;
	});


	/**
	 * Hide toast on click button or after 3 seconds
	 * 
	 * @since 1.0.0
	 */
	jQuery( function($) {
		$('.hide-toast').click( function() {
			$('.updated-option-success, .update-notice-flexify-checkout').fadeOut('fast');
		});

		setTimeout( function() {
			$('.update-notice-flexify-checkout').fadeOut('fast');
		}, 3000);
	});


	/**
	 * Display loader and hide span on click
	 * 
	 * @since 1.0.0
	 */
	jQuery( function($) {
		$('.button-loading').on('click', function() {
			let $btn = $(this);
			let expireDate = $btn.text();
			let btnWidth = $btn.width();
			let btnHeight = $btn.height();

			// keep original width and height
			$btn.width(btnWidth);
			$btn.height(btnHeight);

			// Add spinner inside button
			$btn.html('<span class="spinner-border spinner-border-sm"></span>');
		});

		// Prevent keypress enter
		$('.form-control').keypress( function(event) {
			if (event.keyCode === 13) {
				event.preventDefault();
			}
		});
	});


	/**
	 * Save options in AJAX
	 * 
	 * @since 1.0.0
	 */
	jQuery( function($) {
		let settingsForm = $('form[name="flexify-checkout"]');
		let originalValues = settingsForm.serialize();
		var notificationDelay;
	
		settingsForm.on('change', function() {
			if (settingsForm.serialize() != originalValues) {
				ajax_save_options(); // send option serialized on change
			}
		});
	
		function ajax_save_options() {
			$.ajax({
				url: flexify_checkout_params.ajax_url,
				type: 'POST',
				data: {
					action: 'flexify_checkout_ajax_save_options',
					form_data: settingsForm.serialize(),
				},
				success: function(response) {
					try {
						var responseData = JSON.parse(response); // Parse the JSON response

						if (responseData.status === 'success') {
							originalValues = settingsForm.serialize();
							$('.updated-option-success').addClass('active');
							
							if (notificationDelay) {
								clearTimeout(notificationDelay);
							}
				
							notificationDelay = setTimeout( function() {
								$('.updated-option-success').fadeOut('fast', function() {
									$(this).removeClass('active').css('display', '');
								});
							}, 3000);
						}
					} catch (error) {
						console.log(error);
					}
				}
			});
		}
	});


	/**
	 * Change container visibility
	 * 
	 * @since 1.0.0
	 */
	jQuery( function($) {
		/**
		 * Function to change container visibility
		 * @param {string} method - activation element selector
		 * @param {string} container - container selector
		 */
		function toggleContainerVisibility(method, container) {
			let checked = $(method).prop('checked');

			$(container).toggleClass('d-none', !checked);
		}
	
		/**
		 * Show or hide coupon code field
		 * 
		 * @since 1.0.0
		 */
		toggleContainerVisibility('#enable_auto_apply_coupon_code', '.show-coupon-code-enabled ');
		$('#enable_auto_apply_coupon_code').click( function() {
			toggleContainerVisibility('#enable_auto_apply_coupon_code', '.show-coupon-code-enabled ');
		});
	});


	/**
	 * Allow only number bigger or equal 1 in inputs
	 * 
	 * @since 1.0.0
	 */
	jQuery( function($) {
		let inputField = $('.allow-numbers-be-1');
		
		inputField.on('input', function() {
			let inputValue = $(this).val();
		
			if (inputValue > 1) {
				$(this).val(inputValue);
			} else {
				$(this).val(1);
			}
		});
	});


	/**
	 * Allow insert only numbers, dot and dash in design tab
	 * 
	 * @since 1.0.0
	 */
	jQuery( function($) {
		$('.design-parameters').keydown(function(e) {
			let key = e.charCode || e.keyCode || 0;

			return (
				(key >= 96 && key <= 105) || // numbers (numeric keyboard)
				(key >= 48 && key <= 57) || // numbers (top keyboard)
				key == 190 || // dot
				key == 189 || key == 109 || // dash
				key == 8 // backspace
			);
		});
	});


	/**
	 * Change visibility for elements logo or text
	 * 
	 * @since 1.0.0
	 */
	jQuery(function($) {
		let selectElement = $('select[name="checkout_header_type"]');
		let previousOption = selectElement.val();
	  
		selectElement.change(function() {
		  let selectedOption = $(this).val();
	  
		  if (selectedOption == 'logo') {
			$('.header-styles-option-logo').removeClass('d-none');
			$('.header-styles-option-text').addClass('d-none');
		  } else {
			$('.header-styles-option-text').removeClass('d-none');
			$('.header-styles-option-logo').addClass('d-none');
		  }
	  
		  previousOption = selectedOption;
		});
	  
		if (previousOption == 'logo') {
		  $('.header-styles-option-logo').removeClass('d-none');
		  $('.header-styles-option-text').addClass('d-none');
		} else {
		  $('.header-styles-option-text').removeClass('d-none');
		  $('.header-styles-option-logo').addClass('d-none');
		}
	});


	/**
	 * Open WordPress midia library popup on click
	 * 
	 * @since 1.0.0
	 */
	jQuery(document).ready(function($) {
		var file_frame;
	
		$('#flexify-checkout-search-header-logo').on('click', function(e) {
			e.preventDefault();
	
			// If the media frame already exists, reopen it
			if (file_frame) {
				file_frame.open();
				return;
			}
	
			// create midia frame
			file_frame = wp.media.frames.file_frame = wp.media({
				title: 'Escolher Imagem de cabeçalho',
				button: {
					text: 'Usar esta imagem'
				},
				multiple: false
			});
	
			// When an image is selected, execute the callback function
			file_frame.on('select', function() {
				var attachment = file_frame.state().get('selection').first().toJSON();
				var imageUrl = attachment.url;
			
				// Update the input value with the URL of the selected image
				$('input[name="search_image_header_checkout"]').val(imageUrl).trigger('change'); // Force change
			});

			file_frame.open();
		});
	});


})(jQuery);