<?php

/**
 * Plugin Name: 			Flexify Checkout para WooCommerce
 * Description: 			Extensão que otimiza a finalização de compras em multi etapas para lojas WooCommerce.
 * Plugin URI: 				https://meumouse.com/plugins/flexify-checkout/
 * Author: 					MeuMouse.com
 * Author URI: 				https://meumouse.com/
 * Version: 				1.6.0
 * WC requires at least: 	6.0.0
 * WC tested up to: 		8.2.1
 * Requires PHP: 			7.2
 * Tested up to:      		6.3.1
 * Text Domain: 			flexify-checkout-for-woocommerce
 * Domain Path: 			/languages
 * License: 				GPL2
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Flexify_Checkout
 */
class Flexify_Checkout {

	/**
	 * Plugin slug.
	 *
	 * @var string
	 */
	public static $slug = 'flexify-checkout-for-woocommerce';

	/**
	 * Plugin version.
	 *
	 * @var string
	 */
	public static $version = '1.6.0';

	/**
	 * Settings array.
	 *
	 * @var array
	 */
	public $settings = array();

	/**
	 * Plugin initiated.
	 *
	 * @var bool
	 */
	public $initiated = false;

	/**
	 * Construct the plugin
	 */
	public function __construct() {
		$this->define_constants();

		add_action( 'plugins_loaded', array( $this, 'flexify_checkout_load_checker' ), 5 );
		load_plugin_textdomain( 'flexify-checkout-for-woocommerce', false, dirname( FLEXIFY_CHECKOUT_BASENAME ) . '/languages/' );
	}


	/**
	 * Define constants
	 * 
	 * @since 1.0.0
	 */
	private function define_constants() {
		$this->define( 'FLEXIFY_CHECKOUT_FILE', __FILE__ );
		$this->define( 'FLEXIFY_CHECKOUT_PATH', plugin_dir_path( __FILE__ ) );
		$this->define( 'FLEXIFY_CHECKOUT_URL', plugin_dir_url( __FILE__ ) );
		$this->define( 'FLEXIFY_CHECKOUT_INC_PATH', FLEXIFY_CHECKOUT_PATH . 'inc/' );
		$this->define( 'FLEXIFY_CHECKOUT_TPL_PATH', FLEXIFY_CHECKOUT_PATH . 'templates/' );
		$this->define( 'FLEXIFY_CHECKOUT_BASENAME', plugin_basename( __FILE__ ) );
		$this->define( 'FLEXIFY_CHECKOUT_VERSION', self::$version );
		$this->define( 'FLEXIFY_PLUGIN_VERSION', FLEXIFY_CHECKOUT_VERSION );
		$this->define( 'FLEXIFY_CHECKOUT_SLUG', self::$slug );
	}


	/**
	 * Checker dependencies before activate plugin
	 * 
	 * @since 1.0.0
	 */
	public function flexify_checkout_load_checker() {
		if ( !function_exists( 'is_plugin_active' ) ) {
			include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
		}
	
		// check if WooCommerce is active
		if ( is_plugin_active( 'woocommerce/woocommerce.php' ) ) {
			add_filter( 'plugin_action_links_' . FLEXIFY_CHECKOUT_BASENAME, array( $this, 'flexify_checkout_plugin_links' ), 10, 4 );
			add_action( 'before_woocommerce_init', array( __CLASS__, 'setup_hpos_compatibility' ) );

			$this->setup_compat_autoloader();
			$this->setup_includes();
			$this->initiated = true;
		} else {
			deactivate_plugins( 'flexify-checkout-for-woocommerce/flexify-checkout-for-woocommercet.php' );
			add_action( 'admin_notices', array( $this, 'flexify_checkout_wc_deactivate_notice' ) );
		}

		// display notice if WooCommerce version is bottom 6.0
		if ( is_plugin_active( 'woocommerce/woocommerce.php' ) && version_compare( WC_VERSION, '6.0', '<' ) ) {
			add_action( 'admin_notices', array( $this, 'flexify_checkout_wc_version_notice' ) );
			return;
		}

		// Display notice if PHP version is bottom 7.2
		if ( version_compare( phpversion(), '7.2', '<' ) ) {
			add_action( 'admin_notices', array( $this, 'flexify_checkout_php_version_notice' ) );
			return;
		}
	}


	/**
	 * Run on activation
	 * 
	 * @since 1.0.0
	 */
	public static function activate() {
		self::clear_wc_template_cache();
	}


	/**
	 * Deactivate plugin
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function deactivate() {
		self::clear_wc_template_cache();
	}


	/**
	 * Clear WooCommerce template cache
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function clear_wc_template_cache() {
		if ( function_exists( 'wc_clear_template_cache' ) ) {
			wc_clear_template_cache();
		}
	}


	/**
	 * Setup compability checker autoloader
	 * 
	 * @since 1.0.0
	 */
	private function setup_compat_autoloader() {
		include_once FLEXIFY_CHECKOUT_INC_PATH . 'classes/class-flexify-checkout-compat-autoloader.php';

		Flexify_Checkout_Compat_Autoloader::run(
			array(
				'prefix' => 'Flexify_Checkout_',
				'inc_path' => FLEXIFY_CHECKOUT_INC_PATH . 'classes/compat/',
			)
		);
	}


	/**
	 * Define constant if not already set
	 *
	 * @since 1.0.0
	 * @param string $name Name.
	 * @param string|bool $value Value.
	 */
	private function define( $name, $value ) {
		if ( ! defined( $name ) ) {
			define( $name, $value );
		}
	}


	/**
	 * Load classes
	 * 
	 * @since 1.0.0
	 */
	private function setup_includes() {
		/**
		 * Class init plugin
		 * 
		 * @since 1.0.0
		 */
		include_once FLEXIFY_CHECKOUT_INC_PATH . 'class-flexify-checkout-init.php';

		/**
		 * Admin options
		 * 
		 * @since 1.0.0
		 */
		include_once FLEXIFY_CHECKOUT_INC_PATH . 'admin/class-flexify-checkout-admin-options.php';

		/**
		 * Load core plugin
		 * 
		 * @since 1.0.0
		 */
		include_once FLEXIFY_CHECKOUT_INC_PATH . 'classes/class-flexify-checkout-core.php';

		/**
		 * Load plugin assets
		 * 
		 * @since 1.0.0
		 */
		include_once FLEXIFY_CHECKOUT_INC_PATH . 'classes/class-flexify-checkout-assets.php';

		/**
		 * Load AJAX functions
		 * 
		 * @since 1.0.0
		 */
		include_once FLEXIFY_CHECKOUT_INC_PATH . 'classes/class-flexify-checkout-ajax.php';

		/**
		 * Load class helper
		 * 
		 * @since 1.0.0
		 */
		include_once FLEXIFY_CHECKOUT_INC_PATH . 'classes/class-flexify-checkout-helpers.php';

		/**
		 * Load guest user order
		 * 
		 * @since 1.0.0
		 */
		include_once FLEXIFY_CHECKOUT_INC_PATH . 'classes/class-flexify-checkout-order.php';

		/**
		 * Load checkout sidebar functions
		 * 
		 * @since 1.0.0
		 */
		include_once FLEXIFY_CHECKOUT_INC_PATH . 'classes/class-flexify-checkout-sidebar.php';

		/**
		 * Load checkout functions steps
		 * 
		 * @since 1.0.0
		 */
		include_once FLEXIFY_CHECKOUT_INC_PATH . 'classes/class-flexify-checkout-steps.php';

		/**
		 * Load thankyou page functions
		 * 
		 * @since 1.0.0
		 */
		include_once FLEXIFY_CHECKOUT_INC_PATH . 'classes/class-flexify-checkout-thankyou.php';

		/**
		 * Load API settings
		 * 
		 * @since 1.0.0
		 */
		include_once FLEXIFY_CHECKOUT_INC_PATH . 'classes/class-flexify-checkout-api.php';

		/**
		 * Update checker
		 * 
		 * @since 1.0.0
		 */
		include_once FLEXIFY_CHECKOUT_INC_PATH . 'classes/class-flexify-checkout-updater.php';
	}

	
	/**
	 * WooCommerce version notice
	 * 
	 * @since 1.0.0
	 */
	public function flexify_checkout_wc_version_notice() {
		echo '<div class="notice is-dismissible error">
				<p>' . __( '<strong>Flexify Checkout para WooCommerce</strong> requer a versão do WooCommerce 6.0 ou maior. Faça a atualização do plugin WooCommerce.', 'flexify-checkout-for-woocommerce' ) . '</p>
			</div>';
	}


	/**
	 * Notice if WooCommerce is deactivate
	 * 
	 * @since 1.0.0
	 */
	public function flexify_checkout_wc_deactivate_notice() {
		if ( !current_user_can('install_plugins') ) {
			return;
		}

		echo '<div class="notice is-dismissible error">
				<p>' . __( '<strong>Flexify Checkout para WooCommerce</strong> requer que <strong>WooCommerce</strong> esteja instalado e ativado.', 'flexify-checkout-for-woocommerce' ) . '</p>
			</div>';
	}


	/**
	 * PHP version notice
	 * 
	 * @since 1.0.0
	 */
	public function flexify_checkout_php_version_notice() {
		echo '<div class="notice is-dismissible error">
				<p>' . __( '<strong>Flexify Checkout para WooCommerce</strong> requer a versão do PHP 7.2 ou maior. Contate o suporte da sua hospedagem para realizar a atualização.', 'flexify-checkout-for-woocommerce' ) . '</p>
			</div>';
	}


	/**
	 * Plugin action links
	 * 
	 * @since 1.0.0
	 * @return array
	 */
	public function flexify_checkout_plugin_links( $action_links ) {
		$plugins_links = array(
			'<a href="' . admin_url( 'admin.php?page=flexify-checkout-for-woocommerce' ) . '">'. __( 'Configurar', 'flexify-checkout-for-woocommerce' ) .'</a>',
			'<a href="https://meumouse.com/docs-category/flexify-checkout-para-woocommerce/" target="_blank">'. __( 'Ajuda', 'flexify-checkout-for-woocommerce' ) .'</a>'
		);

		return array_merge( $plugins_links, $action_links );
	}


	/**
	 * Setp compatibility with HPOS/Custom order table feature of WooCommerce.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function setup_hpos_compatibility() {
		if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', FLEXIFY_CHECKOUT_FILE, true );
		}
	}


	/**
	 * Cloning is forbidden.
	 *
	 * @since 1.0.0
	 */
	public function __clone() {
		_doing_it_wrong( __FUNCTION__, esc_html__( 'Trapaceando?', 'flexify-checkout-for-woocommerce' ), '1.0.0' );
	}


	/**
	 * Unserializing instances of this class is forbidden.
	 *
	 * @since 1.0.0
	 */
	public function __wakeup() {
		_doing_it_wrong( __FUNCTION__, esc_html__( 'Trapaceando?', 'flexify-checkout-for-woocommerce' ), '1.0.0' );
	}
}

$flexify_checkout = new Flexify_Checkout();

if ( $flexify_checkout->initiated ) {
	register_activation_hook( __FILE__, array( $flexify_checkout, 'activate' ) );
	register_deactivation_hook( __FILE__, array( $flexify_checkout, 'deactivate' ) );
}