<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

?>

<div id="integrations-settings" class="nav-content">
  <table class="form-table" >
      <tr>
        <th>
           <?php echo esc_html__( 'Ativar recebimento de pagamentos com Pix via Banco Inter (Em breve)', 'flexify-checkout-for-woocommerce' ) ?>
           <span class="flexify-checkout-description"><?php echo esc_html__( 'Ative esta opção para configurar recibimentos via Pix com aprovação automática gratuitamente.', 'flexify-checkout-for-woocommerce' ) ?></span>
        </th>
        <td>
           <div class="form-check form-switch">
              <input type="checkbox" class="toggle-switch" id="enable_inter_bank_pix_api" name="enable_inter_bank_pix_api" value="yes" <?php checked( $this->getSetting( 'enable_inter_bank_pix_api') == 'yes' ); ?> disabled/>
           </div>
        </td>
      </tr>
      <tr>
        <th>
           <?php echo esc_html__( 'Ativar recebimento de pagamentos com boleto bancário via Banco Inter (Em breve)', 'flexify-checkout-for-woocommerce' ) ?>
           <span class="flexify-checkout-description"><?php echo esc_html__( 'Ative esta opção para configurar recibimentos via boleto bancário com aprovação automática gratuitamente.', 'flexify-checkout-for-woocommerce' ) ?></span>
        </th>
        <td>
           <div class="form-check form-switch">
              <input type="checkbox" class="toggle-switch" id="enable_inter_bank_ticket_api" name="enable_inter_bank_ticket_api" value="yes" <?php checked( $this->getSetting( 'enable_inter_bank_ticket_api') == 'yes' ); ?> disabled/>
           </div>
        </td>
      </tr>
  </table>
</div>