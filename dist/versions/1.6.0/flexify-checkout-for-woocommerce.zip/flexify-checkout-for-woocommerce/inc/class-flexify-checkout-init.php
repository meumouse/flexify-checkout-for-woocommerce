<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Class for load API and backend settings
 * 
 * @package MeuMouse.com
 * @version 1.0.0
 */
class Flexify_Checkout_Init {

	public $flexify_checkout_settings = array();
  public $responseObj;
  public $licenseMessage;
  public $showMessage = false;
  public $activateLicense = false;
  public $deactivateLicense = false;
  
  public function __construct() {
    $this->flexify_checkout_settings = get_option( 'flexify_checkout_settings' );

    if ( empty( $this->flexify_checkout_settings ) ) {
        // Default options will be used if there are no existing settings
        $default_settings = $this->get_default_settings();
        update_option( 'flexify_checkout_settings', $default_settings );
        $this->flexify_checkout_settings = $default_settings;
    }

    // init API class after plugins loaded
    add_action( 'plugins_loaded', array( $this, 'load_api_settings' ), 999 );
  }


  /**
	 * Plugin default settings
   * 
   * @since 1.0.0
	 * @return array
	 */
  public function get_default_settings() {
    return array(
      'enable_flexify_checkout' => 'yes',
      'enable_company_field' => 'no',
      'enable_autofill_company_info' => 'no',
      'enable_street_number_field' => 'yes',
      'enable_back_to_shop_button' => 'no',
      'enable_skip_cart_page' => 'no',
      'enable_terms_is_checked_default' => 'yes',
      'enable_aditional_notes' => 'no',
      'enable_optimize_for_digital_products' => 'no',
      'enable_link_image_products' => 'no',
      'enable_fill_address' => 'yes',
      'enable_add_remove_products' => 'yes',
      'enable_ddi_phone_field' => 'no',
      'enable_hide_coupon_code_field' => 'no',
      'enable_auto_apply_coupon_code' => 'no',
      'enable_assign_guest_orders' => 'yes',
      'message_for_existing_user' => 'display_popup',
      'enable_inter_bank_pix_api' => 'no',
      'enable_inter_bank_ticket_api' => 'no',
      'checkout_header_type' => 'logo',
      'search_image_header_checkout' => '',
      'header_width_image_checkout' => '200',
      'unit_header_width_image_checkout' => 'px',
      'text_brand_checkout_header' => 'Checkout',
      'set_primary_color' => '#141D26',
      'set_primary_color_on_hover' => '#33404D',
      'set_placeholder_color' => '#33404D',
      'flexify_checkout_theme' => 'modern',
      'input_border_radius' => '0.5',
      'unit_input_border_radius' => 'rem',
      'enable_address_field_2' => 'no',
      'set_font_family' => 'Inter',
    );
  }


  /**
	 * Function for get plugin general settings
	 * 
	 * @return string 
	 * @since 1.0.0
	 * @access public
	 */
  public function getSetting( $key ) {
    if ( isset( $this->flexify_checkout_settings[ $key ] ) ) {
        return $this->flexify_checkout_settings[ $key ];
    }

    return false;
  }


  /**
   * Load API settings
   * 
   * @since 1.0.0
   */
  public function load_api_settings() {
    if ( current_user_can('manage_woocommerce') ) {
      $this->responseObj = new stdClass();
      $this->responseObj->is_valid = false;
  
      $license_key = get_option( 'flexify_checkout_license_key', '' );
  
      // Save settings on active license
      if (  isset( $_POST['flexify_checkout_active_license'] ) ) {
          update_option( 'flexify_checkout_license_key', $_POST );
          $license_key = !empty( $_POST['flexify_checkout_license_key'] ) ? $_POST['flexify_checkout_license_key'] : '';
          update_option( 'flexify_checkout_license_key', $license_key ) || add_option('flexify_checkout_license_key', $license_key );
          update_option( '_site_transient_update_plugins', '' );
      }

      if ( get_option( 'flexify_checkout_license_status' ) == 'invalid' ) {
        update_option( 'flexify_checkout_license_key', '' );
      }
  
      // Check on the server if the license is valid and update responses and options
      if ( Flexify_Checkout_Api::CheckWPPlugin( $license_key, $this->licenseMessage, $this->responseObj, __FILE__ ) ) {
          update_option( 'flexify_checkout_license_status', 'valid' );

          if ( isset( $_POST['flexify_checkout_active_license'] ) && $this->responseObj && $this->responseObj->is_valid ) {
            $this->activateLicense = true;
          }
      } else {
          update_option( 'flexify_checkout_license_status', 'invalid' );
          wp_cache_delete( 'flexify_checkout_url_server_cache' );

          if ( !empty( $license_key ) && !empty( $this->licenseMessage ) ) {
              $this->showMessage = true;
          }
      }

      // Save settings on deactive license, or remove license status if it is invalid
      if ( isset( $_POST['flexify_checkout_deactive_license'] ) ) {
        if ( Flexify_Checkout_Api::RemoveLicenseKey( __FILE__, $message ) ) {
          update_option( 'flexify_checkout_license_status', 'invalid' );
          delete_option( 'flexify_checkout_license_key' );
          update_option( '_site_transient_update_plugins', '' );
          wp_cache_delete( 'flexify_checkout_url_server_cache' );

          $this->deactivateLicense = true;
        }
      }
    }
  }

}

new Flexify_Checkout_Init();